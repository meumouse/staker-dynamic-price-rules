<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Main class init plugin
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Staker_Dynamic_Price_Rules_Init {

    public $staker_dynamic_price_rules_settings = array();
  
    /**
     * Construct function
     */
    public function __construct() {
        $this->staker_dynamic_price_rules_settings = get_option( 'staker-dynamic-price-rules-setting' );

        if ( empty( $this->staker_dynamic_price_rules_settings ) ) {
            // Default options will be used if there are no existing settings
            $default_settings = $this->get_default_settings();
            update_option( 'staker-dynamic-price-rules-setting', $default_settings );
            $this->staker_dynamic_price_rules_settings = $default_settings;
        }

        $this->load_plugin_classes();
    }


    /**
     * Get default plugin settings
     * 
     * @since 1.0.0
     * @return array
     */
    public function get_default_settings() {
      return array(
        'enable_user_levels' => 'yes',
        'enable_level_item_panel' => 'yes',
        'set_limit_levels' => '3',
        'user_role_select' => 'all_roles',
        'set_amount_for_gain_discount_reference' => '1',
        'show_price_for_logged_users' => 'no',
        'enable_budge_feature' => 'no',
        'enable_bargain_prices' => 'no',
        'get_loop_value_advanced_conditions' => '1',
        'enable_name_field' => 'yes',
        'enable_lastname_field' => 'yes',
        'set_person_type_method' => 'cpf_and_cnpj',
        'enable_social_reason_field' => 'yes',
        'enable_phone_field' => 'yes',
        'enable_email_field' => 'yes',
        'enable_type_service_field' => 'yes',
        'enable_deadline_field' => 'no',
        'enable_aditional_info_field' => 'no',
        'text_social_reason_budget_header' => 'Empresa LTDA.',
        'text_cnpj_budget_header' => 'CNPJ: 12.345.678/0001-20',
        'text_address_budget_header' => 'Rua Fulano de Tal, 100 - Bairro, Cidade - Estado (CEP: 12345-000)',
        'display_logo_budgets' => '',
        'set_primary_color' => '#008aff',
      );
    }


    /**
     * Function to get plugin settings
     * 
     * @since 1.0.0
     * @param string $key The key for the desired configuration
     * @return mixed The setting or false if it does not exist
     */
    public function getSetting( $key ) {
        if ( isset( $this->staker_dynamic_price_rules_settings[$key] ) ) {
            return $this->staker_dynamic_price_rules_settings[$key];
        }

        return false;
    }


    /**
     * Check settings for load classes
     * 
     * @since 1.0.0
     * @return void
     */
    private function load_plugin_classes() {
      $settings = get_option( 'staker-dynamic-price-rules-setting' );

      // load user levels class
      if ( isset( $settings['enable_user_levels'] ) && $settings['enable_user_levels'] == 'yes' ) {
        include_once STAKER_DYNAMIC_PRICE_RULES_INC_DIR . 'classes/class-staker-dynamic-price-rules-user-levels.php';
      }

      // load budget class
      if ( isset( $settings['enable_budge_feature'] ) && $settings['enable_budge_feature'] == 'yes' ) {
        include_once STAKER_DYNAMIC_PRICE_RULES_INC_DIR . 'classes/class-staker-dynamic-price-rules-budget.php';
      }
    }
}

new Staker_Dynamic_Price_Rules_Init();