<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
  
?>

<div id="general" class="nav-content">
  <table class="form-table">
      <tr>
        <th>
           <?php echo esc_html__( 'Ativar recurso de níveis de usuários', 'staker-dynamic-price-rules' ) ?>
           <span class="staker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para permitir definir níveis para usuários, para receber benefícios ou ter acesso a descontos exclusivos.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
           <div class="form-check form-switch">
              <input type="checkbox" class="toggle-switch" id="enable_user_levels" name="enable_user_levels" value="yes" <?php checked( $this->getSetting( 'enable_user_levels' ) == 'yes' ); ?> />
           </div>
        </td>
      </tr>
      <tr class="set-user-levels d-none">
        <th>
           <?php echo esc_html__( 'Mostrar informação de nível no painel', 'staker-dynamic-price-rules' ) ?>
           <span class="staker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para mostrar informação do nível do usuário na conta de cliente.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
           <div class="form-check form-switch">
              <input type="checkbox" class="toggle-switch" id="enable_level_item_panel" name="enable_level_item_panel" value="yes" <?php checked( $this->getSetting( 'enable_level_item_panel' ) == 'yes' ); ?> />
           </div>
        </td>
      </tr>
      <tr class="set-user-levels d-none">
        <th>
           <?php echo esc_html__( 'Quantidade de níveis para usuários', 'staker-dynamic-price-rules' ) ?>
           <span class="staker-dynamic-price-rules-description"><?php echo esc_html__( 'Define o limite de níveis para usuários.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <input type="number" id="set_limit_levels" class="form-control input-control-wd-5 allow-numbers-be-1 input-control-wd-7-7rem" name="set_limit_levels" placeholder="3" value="<?php echo $this->getSetting( 'set_limit_levels' ) ?>">
        </td>
      </tr>
      <tr class="set-user-levels d-none">
         <td>
            <fieldset id="set-user-levels-fieldset">
               <?php
                  $customLevelUsers = array();
                  $customLevelUsers = get_option( 'staker_dynamic_price_rules_user_levels' );
                  $customLevelUsers = maybe_unserialize( $customLevelUsers );
                  $limit_levels = $this->getSetting( 'set_limit_levels' );
                  
                  for ( $i = 1; $i <= $limit_levels; $i++ ) {
                     $current_user_level_name = isset( $customLevelUsers[ $i ]['name'] ) ? $customLevelUsers[ $i ]['name'] : 'Nível ' . $i; ?>
                     
                     <div class="input-group mb-3" data-user-levels="<?php echo $i; ?>">
                        <input type="text" class="get-user-level-number-array input-control-wd-5 border-right-0" disabled value="<?php echo $i; ?>"/>
                        <input type="text" class="form-control input-control-wd-10 text-center" name="set_user_level[<?php echo $i; ?>][name]" placeholder="Nível" value="<?php echo esc_attr( $current_user_level_name ); ?>">
                     </div>
                     <?php
                  }
                  ?>
            </fieldset>
         </td>
      </tr>
      <tr class="set-user-levels d-none">
         <th>
            <?php echo esc_html__( 'Aplicar níveis de usuários para tipo de função', 'staker-dynamic-price-rules' ) ?>
            <span class="staker-dynamic-price-rules-description"><?php echo esc_html__( 'Escolha para qual tipo de usuário os níveis serão aplicados.', 'staker-dynamic-price-rules' ) ?></span>
         </th>
         <td>
         <select name="user_role_select" id="user-role-select" class="form-select">
            <option value="all_roles" <?php echo ( $this->getSetting( 'user_role_select' ) == 'all_roles' ) ? "selected=selected" : "" ?>><?php echo esc_html__( 'Aplicar para todos os tipos de usuários (Padrão)', 'staker-dynamic-price-rules' ) ?></option>
            <?php
            $user_role_translations = array(
               'subscriber' => __( 'Assinante', 'staker-dynamic-price-rules' ),
               'editor' => __( 'Editor', 'staker-dynamic-price-rules' ),
               'author' => __( 'Autor', 'staker-dynamic-price-rules' ),
               'contributor' => __( 'Colaborador', 'staker-dynamic-price-rules' ),
               'administrator' => __( 'Administrador', 'staker-dynamic-price-rules' ),
               'customer' => __( 'Cliente', 'staker-dynamic-price-rules' ),
               'shop_manager' => __( 'Gerente de loja', 'staker-dynamic-price-rules' ),
            );

            $user_roles = wp_roles()->roles;

            foreach ( $user_roles as $role_key => $role ) {
               $selected = ( $this->getSetting( 'user_role_select' ) == $role_key ) ? "selected=selected" : "";
               $translated_role_name = isset( $user_role_translations[$role_key] ) ? $user_role_translations[$role_key] : $role['name'];

               echo '<option value="'. esc_attr( $role_key ) .'" '. $selected .'>'. esc_html( $translated_role_name ) .'</option>';
            }
            ?>
         </select>
         </td>
      </tr>
      <tr>
        <th>
           <?php echo esc_html__( 'Mostrar preço apenas para usuários que estão logados', 'staker-dynamic-price-rules' ) ?>
           <span class="staker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para que o preço seja exibido somente para usuários que estão logados no site.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
           <div class="form-check form-switch">
              <input type="checkbox" class="toggle-switch" id="show_price_for_logged_users" name="show_price_for_logged_users" value="yes" <?php checked( $this->getSetting( 'show_price_for_logged_users' ) == 'yes' ); ?> />
           </div>
        </td>
      </tr>
      <tr>
        <th>
           <?php echo esc_html__( 'Permitir negociação de preços', 'staker-dynamic-price-rules' ) ?>
           <span class="staker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para permitir que o usuário negocie o preço de produtos.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td class="d-flex align-items-center">
            <div class="form-check form-switch me-3">
               <input type="checkbox" class="toggle-switch" id="enable_bargain_prices" name="enable_bargain_prices" value="yes" <?php checked( $this->getSetting( 'enable_bargain_prices' ) == 'yes' ); ?> />
            </div>
            <div class="negotiate-container">
               <a class="sdpr-manage-negotiates-trigger btn btn-outline-primary" href="#"><?php echo esc_html__( 'Gerenciar ofertas', 'staker-dynamic-price-rules' ) ?></a> 
               
               <div class="sdpr-manage-negotiates-container">
                  <div class="sdpr-manage-negotiates-content">
                     <div class="sdpr-manage-negotiates-header">
                        <h5 class="sdpr-popup-title"><?php echo esc_html__( 'Gerenciar ofertas de usuários', 'staker-dynamic-price-rules' ); ?></h5>
                        <button class="sdpr-close-manage-negotiates btn-close fs-lg" aria-label="Fechar"></button>
                     </div>
                     <div>
                        <?php
                        $offers = get_option('prices_negotiated_by_users', array());

                        $pending_offers = array_filter( $offers, function( $offer ) {
                           return isset( $offer['status'] ) && $offer['status'] === 'pending';
                        });

                        if ( empty( $pending_offers ) ) {
                           echo '<p>' . esc_html__('Não existem ofertas pendentes no momento.', 'staker-dynamic-price-rules') . '</p>';
                        } else {
                           echo '<table class="wp-list-table">';
                           echo '<thead><tr>';
                           echo '<th>' . esc_html__('Produto', 'staker-dynamic-price-rules') . '</th>';
                           echo '<th>' . esc_html__('Preço original', 'staker-dynamic-price-rules') . '</th>';
                           echo '<th>' . esc_html__('Preço ofertado', 'staker-dynamic-price-rules') . '</th>';
                           echo '<th>' . esc_html__('E-mail do usuário', 'staker-dynamic-price-rules') . '</th>';
                           echo '<th>' . esc_html__('Ações', 'staker-dynamic-price-rules') . '</th>';
                           echo '</tr></thead>';
                           echo '<tbody>';

                           foreach ($pending_offers as $offer) {
                              echo '<tr>';
                              echo '<td>' . esc_html(get_the_title($offer['product_id'])) . '</td>';
                              echo '<td>' . wc_price(str_replace(',', '.', $offer['original_price'])) . '</td>';
                              echo '<td>' . wc_price(str_replace(',', '.', $offer['negotiated_price'])) . '</td>';
                              echo '<td>' . esc_html(get_userdata($offer['user_id'])->user_email) . '</td>';
                              echo '<td>';
                              echo '<a href="#" class="accept-offer" data-offer="' . esc_attr(json_encode($offer)) . '" data-action="accept">' . esc_html__('Aceitar', 'staker-dynamic-price-rules') . '</a>';
                              echo '<a href="#" class="decline-offer" data-offer="' . esc_attr(json_encode($offer)) . '" data-action="decline">' . esc_html__('Recusar', 'staker-dynamic-price-rules') . '</a>';
                              echo '</td>';
                              echo '</tr>';
                           }

                           echo '</tbody>';
                           echo '</table>';
                        }
                        ?>
                     </div>
                  </div>
               </div>
            </div>
        </td>
      </tr>
  </table>
</div>