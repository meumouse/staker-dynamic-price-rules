<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
  
?>

<div id="points" class="nav-content">
  <table class="form-table">
      <tr>
        <th>
           <?php echo esc_html__( 'Ativar recurso de pontos por compra', 'staker-dynamic-price-rules' ) ?>
           <span class="staker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para permitir que usuários recebam pontos para cada compra realizada.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
           <div class="form-check form-switch">
              <input type="checkbox" class="toggle-switch" id="enable_purchase_points" name="enable_purchase_points" value="yes" <?php checked( $this->getSetting( 'enable_purchase_points' ) == 'yes' ); ?> />
           </div>
        </td>
      </tr>
      <tr class="set-user-points d-none">
        <th>
           <?php echo esc_html__( 'Rótulo do ponto', 'staker-dynamic-price-rules' ) ?>
           <span class="staker-dynamic-price-rules-description"><?php echo esc_html__( 'Define o nome de exibição dos pontos.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="input-group input-control-wd-20">
              <input type="text" id="set_point_label_singular" class="form-control input-control-wd-10" name="set_point_label_singular" placeholder="Ponto" value="<?php echo $this->getSetting( 'set_point_label_singular' ) ?>">
              <input type="text" id="set_point_label_plural" class="form-control input-control-wd-10" name="set_point_label_plural" placeholder="Ponto" value="<?php echo $this->getSetting( 'set_point_label_plural' ) ?>">
            </div>
        </td>
      </tr>
      <tr class="set-user-points d-none">
        <th>
           <?php echo esc_html__( 'Ganho de pontos por valor gasto do usuário', 'staker-dynamic-price-rules' ) ?>
           <span class="staker-dynamic-price-rules-description"><?php echo esc_html__( 'Define a quantidade de pontos que o usuário pode ganhar por valor gasto com a moeda local. Por exemplo: Para cada R$1,00 gasto ganhe 1 ponto.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="quantity-points-per-currency-container">
              <div>
                <div class="input-group">
                    <span class="input-group-text"><?php echo get_woocommerce_currency_symbol(); ?></span>
                    <input type="number" id="set_amount_reference_points" class="form-control input-control-wd-5" name="set_amount_reference_points" placeholder="1" value="<?php echo $this->getSetting( 'set_amount_reference_points' ) ?>">
                </div>
              </div>
              <div class="equal-points-for-currency mx-2">=</div>
              <div>
                <div class="input-group">
                    <input type="number" id="set_number_points_per_amount" class="form-control input-control-wd-5" name="set_number_points_per_amount" placeholder="1" value="<?php echo $this->getSetting( 'set_number_points_per_amount' ) ?>">
                    <span id="get-point-label-singular" class="input-group-text px-3"><?php echo $this->getSetting( 'set_point_label_singular' ); ?></span>
                </div>
              </div>
            </div>
        </td>
      </tr>
      <tr class="set-user-points d-none">
        <th>
           <?php echo esc_html__( 'Taxa de conversão para descontos', 'staker-dynamic-price-rules' ) ?>
           <span class="staker-dynamic-price-rules-description"><?php echo esc_html__( 'Define o valor de desconto que o usuário pode receber para cada ponto disponível. Por exemplo: A cada 10 pontos ganhe R$1,00 de desconto.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <div class="quantity-points-per-currency-container">
              <div>
                <div class="input-group">
                    <input type="number" id="set_discount_number_points" class="form-control input-control-wd-5" name="set_discount_number_points" placeholder="1" value="<?php echo $this->getSetting( 'set_discount_number_points' ) ?>">
                    <span id="get-point-label-plural" class="input-group-text px-3"><?php echo $this->getSetting( 'set_point_label_plural' ); ?></span>
                </div>
              </div>
              <div class="equal-points-for-currency mx-2">=</div>
              <div>
                <div class="input-group">
                    <span class="input-group-text"><?php echo get_woocommerce_currency_symbol(); ?></span>
                    <input type="number" id="set_amount_for_gain_discount_reference" class="form-control input-control-wd-5" name="set_amount_for_gain_discount_reference" placeholder="1" value="<?php echo $this->getSetting( 'set_amount_for_gain_discount_reference' ) ?>">
                </div>
              </div>
            </div>
        </td>
      </tr>
      <tr class="set-user-points d-none">
         <th>
            <?php echo esc_html__( 'Validade do ponto', 'staker-dynamic-price-rules' ) ?>
            <span class="staker-dynamic-price-rules-description"><?php echo esc_html__( 'Permite definir uma validade limite para resgate do ponto por descontos. Ou deixe em branco, para não definir uma validade.', 'staker-dynamic-price-rules' ) ?></span>
         </th>
         <td>
            <div class="input-group">
                <input type="number" id="expire_date_user_points_value" class="form-control input-control-wd-5 border-right-0" name="expire_date_user_points_value" placeholder="365" value="<?php echo $this->getSetting( 'expire_date_user_points_value' ) ?>">
                <select id="expire_date_user_points_method" class="form-select get-discount-method-main-price" name="expire_date_user_points_method">
                  <option value="days" <?php echo ( $this->getSetting( 'expire_date_user_points_method' ) == 'days' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Dia(s)', 'staker-dynamic-price-rules' ) ?></option>
                  <option value="weeks" <?php echo ( $this->getSetting( 'expire_date_user_points_method' ) == 'weeks' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Semana(s)', 'staker-dynamic-price-rules' ) ?></option>
                  <option value="months" <?php echo ( $this->getSetting( 'expire_date_user_points_method' ) == 'months' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Mês(es)', 'staker-dynamic-price-rules' ) ?></option>
                  <option value="years" <?php echo ( $this->getSetting( 'expire_date_user_points_method' ) == 'years' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Ano(s)', 'staker-dynamic-price-rules' ) ?></option>
                </select>
            </div>
         </td>
      </tr>
      <tr class="set-user-points d-none">
        <th>
           <?php echo esc_html__( 'Mostrar campo de resgate de descontos no carrinho', 'staker-dynamic-price-rules' ) ?>
           <span class="staker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para permitir que os usuários escolham quantos pontos usar para trocar por descontos na página do carrinho.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
           <div class="form-check form-switch">
              <input type="checkbox" class="toggle-switch" id="get_discount_with_points_cart" name="get_discount_with_points_cart" value="yes" <?php checked( $this->getSetting( 'get_discount_with_points_cart' ) == 'yes' ); ?> />
           </div>
        </td>
      </tr>
      <tr class="set-user-points d-none">
        <th>
           <?php echo esc_html__( 'Mostrar campo de resgate de descontos no checkout', 'staker-dynamic-price-rules' ) ?>
           <span class="staker-dynamic-price-rules-description"><?php echo esc_html__('Ative esta opção para permitir que os usuários escolham quantos pontos usar para trocar por descontos na página de finalização de compras.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
           <div class="form-check form-switch">
              <input type="checkbox" class="toggle-switch" id="get_discount_with_points_checkout" name="get_discount_with_points_checkout" value="yes" <?php checked( $this->getSetting( 'get_discount_with_points_checkout' ) == 'yes' ); ?> />
           </div>
        </td>
      </tr>
      <tr class="set-user-points d-none">
          <th>
            <?php echo esc_html__( 'Gerenciar pontuação de usuários', 'staker-dynamic-price-rules' ) ?>
            <span class="staker-dynamic-price-rules-description"><?php echo esc_html__( 'Gerencie e altere os pontos de cada usuário.', 'staker-dynamic-price-rules' ) ?></span>
          </th>
          <td>
            <a class="sdpr-display-popup-points btn btn-outline-primary line-height-2-2" href="#"><?php echo esc_html__( 'Gerenciar pontos', 'staker-dynamic-price-rules' ) ?></a>
            <div class="sdpr-popup-container-points">
              <div class="sdpr-popup-content-points">
                <div class="sdpr-popup-header-points">
                    <h5 class="sdpr-popup-title"><?php echo esc_html__( 'Gerenciar pontos de usuários:', 'staker-dynamic-price-rules' ) ?></h5>
                    <button class="sdpr-close-popup-points btn-close fs-lg" aria-label="Fechar"></button>
                </div>
                <div class="manage-user-points">
                  <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>ID do Usuário</th>
                            <th>Nome do Usuário</th>
                            <th>Pontos</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $users = get_users();

                        foreach ( $users as $user ) {
                            $user_id = $user->ID;
                            $user_name = $user->display_name;
                            $user_points = get_user_meta( $user_id, 'user_points', true );
                            $user_points = isset( $user_points ) ? $user_points : '0'; ?>

                            <tr>
                                <td><?php echo $user_id; ?></td>
                                <td><?php echo $user_name; ?></td>
                                <td><?php echo $user_points; ?></td>
                                <td>
                                    <a href="#" class="editar-pontos" data-user-id="<?php echo $user_id; ?>">Editar</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </td>
      </tr>
  </table>
</div>