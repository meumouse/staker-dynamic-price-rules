<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
  
?>

<div id="conditions" class="nav-content">
    <table class="form-table">
      <tr class="set-user-levels d-none">
         <th>
            <?php echo esc_html__( 'Condição para usuário passar de nível', 'staker-dynamic-price-rules' ) ?>
            <span class="staker-dynamic-price-rules-description"><?php echo esc_html__( 'Define o tipo de condição necessária para que o usuário passe para o próximo nível e receba outros benefícios.', 'staker-dynamic-price-rules' ) ?></span>
         </th>
         <td>
          <fieldset id="set-user-levels-fieldset">
               <?php
                  $set_conditions_user_levels_exp = get_option( 'staker_dynamic_price_rules_user_levels_exp' );
                  $set_conditions_user_levels_exp = maybe_unserialize( $set_conditions_user_levels_exp );
                  $customLevelUsers = get_option( 'staker_dynamic_price_rules_user_levels' );
                  $customLevelUsers = maybe_unserialize( $customLevelUsers );
                  $limit_levels = $this->getSetting( 'set_limit_levels' );
                  
                  for ( $i = 1; $i <= $limit_levels; $i++ ) {
                    $current_user_level_name = isset( $customLevelUsers[ $i ]['name'] ) ? $customLevelUsers[ $i ]['name'] : 'Nível ' . $i;
                    $current_user_level_exp = isset( $set_conditions_user_levels_exp[ $i ]['amount'] ) ? $set_conditions_user_levels_exp[ $i ]['amount'] : 0;
                    $current_user_level_exp_method = isset( $set_conditions_user_levels_exp[ $i ]['method'] ) ? $set_conditions_user_levels_exp[ $i ]['method'] : 'purchases'; ?>
                    
                    <div class="input-group mb-3">
                      <input type="text" class="get-user-level-number-array input-control-wd-10 border-right-0" disabled value="<?php echo $current_user_level_name; ?>"/>
                      <input type="text" class="form-control input-control-wd-5 text-center border-right-0" name="set_user_level_exp[<?php echo $i; ?>][amount]" placeholder="5" value="<?php echo esc_attr( $current_user_level_exp ); ?>">
                      <select class="form-select user-level-exp-condition-method" name="set_user_level_exp[<?php echo $i ?>][method]">
                          <option value="purchases" <?php echo $current_user_level_exp_method == 'purchases' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Compras', 'staker-dynamic-price-rules' ) ?></option>
                      </select>
                    </div>
                    <?php
                  }
                  ?>
            </fieldset>
         </td>
      </tr>
      <tr class="set-user-levels d-none">
         <td class="container-separator"></td>
      </tr>
      <tr class="set-user-levels d-none">
         <th>
            <?php echo esc_html__( 'Permitir formas de pagamento por nível', 'staker-dynamic-price-rules' ) ?>
            <span class="staker-dynamic-price-rules-description"><?php echo esc_html__( 'Permite definir quais formas de pagamento estão disponíveis para cada nível do usuário.', 'staker-dynamic-price-rules' ) ?></span>
         </th>
         <td>
          <fieldset id="set-enable-payment-methods-per-level">
              <?php
                $enabled_payment_gateway = get_option( 'staker_dynamic_price_rules_enable_payment_methods_condition' );
                $enabled_payment_gateway = maybe_unserialize( $enabled_payment_gateway );
                $gatewayLevelUser = get_option( 'staker_dynamic_price_rules_user_levels' );
                $gatewayLevelUser = maybe_unserialize( $gatewayLevelUser );
                $limit_levels = $this->getSetting( 'set_limit_levels' );
                
                for ( $i = 1; $i <= $limit_levels; $i++ ) {
                  $current_user_level_name = isset( $gatewayLevelUser[$i]['name'] ) ? $gatewayLevelUser[$i]['name'] : 'Nível ' . $i; ?>
                  
                  <div class="payment-conditions-item" data-levels-conditions-<?php echo $i; ?>>
                    <div class="input-group mb-3">
                        <input type="text" class="get-user-level-number-array input-control-wd-10 border-right-0" disabled value="<?php echo $current_user_level_name; ?>"/>
                        <a class="sdpr-display-popup-payments btn btn-outline-primary line-height-2-2" href="#"><?php echo esc_html__( 'Configurar formas de pagamento', 'staker-dynamic-price-rules' ) ?></a>
                    </div>

                    <div class="sdpr-popup-container-payments">
                        <div class="sdpr-popup-content-payments">
                            <div class="sdpr-popup-header-payments">
                                <h5 class="sdpr-popup-title"><?php echo sprintf( __( 'Formas de pagamento para %s', 'staker-dynamic-price-rules' ), $current_user_level_name ); ?></h5>
                                <button class="sdpr-close-popup-payments btn-close fs-lg" aria-label="Fechar"></button>
                            </div>
                            <span class="d-block text-left mb-4"><?php echo esc_html__( 'Ative as formas de pagamento disponíveis para o usuário deste nível.', 'staker-dynamic-price-rules' ) ?></span>
                            
                            <ul class="list-group">
                              <?php $payment_gateways = WC()->payment_gateways->payment_gateways();

                              foreach ( $payment_gateways as $gateway ) {
                                $gateway_id = esc_attr( $gateway->id );
                                $gateway_name = esc_html( $gateway->get_title() );
                                $current_gateway = isset( $enabled_payment_gateway[$i][$gateway_id] ) ? 'yes' : 'no'; ?>

                                <li class="list-group-item" data-payment-method-<?php echo $gateway->id ?>>
                                  <input type="checkbox" class="toggle-switch" value="yes" name="enabled_gateway[<?php echo $i; ?>][<?php echo esc_attr( $gateway_id ); ?>]" <?php checked( $current_gateway == 'yes' ); ?>>
                                  <label class="form-check-label" for="<?php echo esc_attr( $gateway_id ); ?>"><?php echo $gateway_name; ?></label>
                                </li>
                              <?php
                              }
                              ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php
                }
                ?>
            </fieldset>
        </td>
      </tr>
      <tr class="set-user-levels d-none">
         <td class="container-separator"></td>
      </tr>
      <tr>
        <th>
          <?php echo esc_html__( 'Condições avançadas', 'staker-dynamic-price-rules' ) ?>
          <span class="staker-dynamic-price-rules-description"><?php echo esc_html__( 'Permite definir quais formas de pagamento estão disponíveis para cada nível do usuário.', 'staker-dynamic-price-rules' ) ?></span>
        </th>
        <td>
            <a class="sdpr-display-popup-advanced-conditions btn btn-outline-primary" href="#"><?php echo esc_html__( 'Gerenciar condições avançadas', 'staker-dynamic-price-rules' ) ?></a> 
            <div class="sdpr-popup-container-advanced-conditions">
              <div class="sdpr-popup-content-advanced-conditions">
                <div class="sdpr-popup-header-advanced-conditions">
                    <h5 class="sdpr-popup-title"><?php echo esc_html__( 'Gerenciar condições avançadas', 'staker-dynamic-price-rules' ); ?></h5>
                    <button class="sdpr-close-popup-advanced-conditions btn-close fs-lg" aria-label="Fechar"></button>
                </div>

                <input type="hidden" id="loop-counter-advanced-conditions" name="get_loop_value_advanced_conditions" value="<?php echo $this->getSetting( 'get_loop_value_advanced_conditions' ) ?>" />

                <div class="advanced-conditions-container">
                    <?php
                    $advanced_conditions = get_option( 'staker_dynamic_price_rules_advanced_conditions' );
                    $advanced_conditions = maybe_unserialize( $advanced_conditions );
                    $formatted_array = array();

                    for ( $a = 1; $a <= $this->getSetting( 'get_loop_value_advanced_conditions' ); $a++ ) {
                      $current_rule_type = isset( $advanced_conditions[$a]['rule_type'] ) ? $advanced_conditions[$a]['rule_type'] : 0;
                      $current_user_role = isset( $advanced_conditions[$a]['user_role'] ) ? $advanced_conditions[$a]['user_role'] : 'all_users';
                      $current_product_filter = isset( $advanced_conditions[$a]['product_filter'] ) ? $advanced_conditions[$a]['product_filter'] : 'all_products';
                      $current_apply_discount_method = isset( $advanced_conditions[$a]['apply_discount_method'] ) ? $advanced_conditions[$a]['apply_discount_method'] : 'cart';
                      $current_min_qtd_for_apply_discount = isset( $advanced_conditions[$a]['min_qtd'] ) ? $advanced_conditions[$a]['min_qtd'] : 0;
                      $current_discount_method = isset( $advanced_conditions[$a]['discount_method'] ) ? $advanced_conditions[$a]['discount_method'] : 'percentage';
                      $current_discount_value = isset( $advanced_conditions[$a]['discount_value'] ) ? $advanced_conditions[$a]['discount_value'] : 0;
                      $current_shipping_method = isset( $advanced_conditions[$a]['shipping_method'] ) ? $advanced_conditions[$a]['shipping_method'] : 0;
                      $current_shipping_operator = isset( $advanced_conditions[$a]['shipping_operator'] ) ? $advanced_conditions[$a]['shipping_operator'] : 0;
                      $current_apply_condition = isset( $advanced_conditions[$a]['apply_condition'] ) ? $advanced_conditions[$a]['apply_condition'] : 0;
                      $current_operator_condition = isset( $advanced_conditions[$a]['operator_condition'] ) ? $advanced_conditions[$a]['operator_condition'] : 0;
                      $current_condition_value = isset( $advanced_conditions[$a]['condition_value'] ) ? $advanced_conditions[$a]['condition_value'] : '';
                      $current_use_limit = isset( $advanced_conditions[$a]['use_limit'] ) ? $advanced_conditions[$a]['use_limit'] : '';
                      $current_start_date = isset( $advanced_conditions[$a]['start_date'] ) ? $advanced_conditions[$a]['start_date'] : '';
                      $current_end_date = isset( $advanced_conditions[$a]['end_date'] ) ? $advanced_conditions[$a]['end_date'] : '';
                      $current_specific_products = isset( $advanced_conditions[$a]['specific_products'] ) ? $advanced_conditions[$a]['specific_products'] : '';
                      $current_specific_categories = isset( $advanced_conditions[$a]['specific_categories'] ) ? $advanced_conditions[$a]['specific_categories'] : '';
                      $current_specific_attributes = isset( $advanced_conditions[$a]['specific_attributes'] ) ? $advanced_conditions[$a]['specific_attributes'] : ''; 
                      $current_specific_users = isset( $advanced_conditions[$a]['specific_users'] ) ? $advanced_conditions[$a]['specific_users'] : '';
                      $current_specific_role = isset( $advanced_conditions[$a]['specific_roles'] ) ? $advanced_conditions[$a]['specific_roles'] : 'customer';

                      $formatted_array[$a] = array('rule_type' => $current_rule_type);

                      if ( $current_rule_type == 'discount' ) {
                        $formatted_array[$a]['discount_options'] = array(
                          'user_role' => $current_user_role,
                          'product_filter' => $current_product_filter,
                          'apply_discount_method' => $current_apply_discount_method,
                          'min_qtd' => $current_min_qtd_for_apply_discount,
                          'discount_method' => $current_discount_method,
                          'discount_value' => $current_discount_value,
                          'apply_condition' => $current_apply_condition,
                          'operator_condition' => $current_operator_condition,
                          'condition_value' => $current_condition_value,
                          'use_limit' => $current_use_limit,
                          'start_date' => $current_start_date,
                          'end_date' => $current_end_date,
                          'specific_products' => $current_specific_products,
                          'specific_categories' => $current_specific_categories,
                          'specific_attributes' => $current_specific_attributes,
                          'specific_users' => $current_specific_users,
                          'specific_role' => $current_specific_role,
                        );
                      } elseif ( $current_rule_type == 'shipping' ) {
                        $formatted_array[$a]['shipping_options'] = array(
                          'user_role' => $current_user_role,
                          'product_filter' => $current_product_filter,
                          'shipping_method' => $current_shipping_method,
                          'shipping_operator' => $current_shipping_operator,
                          'apply_condition' => $current_apply_condition,
                          'operator_condition' => $current_operator_condition,
                          'condition_value' => $current_condition_value,
                          'use_limit' => $current_use_limit,
                          'start_date' => $current_start_date,
                          'end_date' => $current_end_date,
                          'specific_products' => $current_specific_products,
                          'specific_categories' => $current_specific_categories,
                          'specific_attributes' => $current_specific_attributes,
                          'specific_users' => $current_specific_users,
                          'specific_role' => $current_specific_role,
                        );
                      }

                      ?>

                        <div class="advanced-condition-item" data-advanced-condition-item="<?php echo $a ?>" data-loop-number="<?php echo $a ?>">

                          <div class="first-line-settings">
                            <div class="rule-type-item d-grid me-3">
                              <label class="form-label"><?php echo esc_html__( 'Tipo da regra *', 'staker-dynamic-price-rules' ); ?></label>

                              <select class="form-select rule-type" data-rule-type-item="<?php echo $a ?>" name="advanced_condition[<?php echo $a ?>][rule_type]" data-loop-number="<?php echo $a ?>">
                                <option value="0" <?php echo esc_attr( $current_rule_type ) == '0' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Selecione um tipo de regra', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="discount" <?php echo esc_attr( $current_rule_type ) == 'discount' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Desconto', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="shipping" <?php echo esc_attr( $current_rule_type ) == 'shipping' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Forma de entrega', 'staker-dynamic-price-rules' ) ?></option>
                              </select>
                            </div>

                            <div class="user-role-item d-grid me-3">
                              <label class="form-label"><?php echo esc_html__( 'Selecionar Usuário/Função *', 'staker-dynamic-price-rules' ); ?></label>

                              <select class="form-select user-role-filter" name="advanced_condition[<?php echo $a ?>][user_role]" data-loop-number="<?php echo $a ?>">
                                <option value="all_users" <?php echo esc_attr( $current_user_role ) == 'all_users' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Todos os usuários (Padrão)', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="all_roles" <?php echo esc_attr( $current_user_role ) == 'all_roles' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Todas as funções', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="specific_user" <?php echo esc_attr( $current_user_role ) == 'specific_user' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Usuários específicos', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="specific_role" <?php echo esc_attr( $current_user_role ) == 'specific_role' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Função específica', 'staker-dynamic-price-rules' ) ?></option>
                              </select>
                            </div>

                            <div class="product-filter-item d-grid me-3">
                              <label class="form-label"><?php echo esc_html__( 'Filtro de produtos *', 'staker-dynamic-price-rules' ); ?></label>

                              <select class="form-select product-filter" name="advanced_condition[<?php echo $a ?>][product_filter]" data-loop-number="<?php echo $a ?>">
                                <option value="all_products" <?php echo esc_attr( $current_product_filter ) == 'all_products' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Todos os produtos (Padrão)', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="all_categories" <?php echo esc_attr( $current_product_filter ) == 'all_categories' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Todas as categorias', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="all_attributes" <?php echo esc_attr( $current_product_filter ) == 'all_attributes' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Todos os atributos', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="select_specific_products" <?php echo esc_attr( $current_product_filter ) == 'select_specific_products' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Produtos específicos', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="select_specific_categories" <?php echo esc_attr( $current_product_filter ) == 'select_specific_categories' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Categorias específicas', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="select_specific_attributes" <?php echo esc_attr( $current_product_filter ) == 'select_specific_attributes' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Atributos específicos', 'staker-dynamic-price-rules' ) ?></option>
                              </select>
                            </div>

                            <button class="exclude-advanced-condition-item btn btn-outline-danger btn-icon" data-exclude-advanced-item="<?php echo $a ?>">
                              <svg class="staker-dynamic-price-rules-danger-icon" width="20" height="20" viewBox="0 0 24 24"><path d="M15 2H9c-1.103 0-2 .897-2 2v2H3v2h2v12c0 1.103.897 2 2 2h10c1.103 0 2-.897 2-2V8h2V6h-4V4c0-1.103-.897-2-2-2zM9 4h6v2H9V4zm8 16H7V8h10v12z"></path></svg>
                            </button>
                          </div>

                          <!-- Select specific users -->
                          <div class="specific-users-container get-specific-value mt-4 mb-5 d-none" data-specific-users-item="<?php echo $a ?>" data-loop-number="<?php echo $a ?>">
                              <label class="form-label"><?php echo esc_html__( 'Usuários específicos', 'staker-dynamic-price-rules' ); ?></label>
                              <div class="d-flex align-items-center ajax-search-with-loader">
                                  <input type="text" class="form-control user-search" data-user-search="<?php echo $a ?>" placeholder="<?php echo esc_html__( 'Comece a digitar para pesquisar...', 'staker-dynamic-price-rules' ); ?>">
                                  <span class="spinner-border d-none"></span>
                              </div>
                              <div class="specific-user-results d-none" data-user-results="<?php echo $a ?>">
                                  <ul id="user-results-<?php echo $a ?>" class="list-group list-itens-overflow"></ul>
                              </div>
                              <input type="hidden" name="advanced_condition[<?php echo $a ?>][specific_users]" value="<?php echo esc_attr( $current_specific_users ) ?>" data-save-specific-users="<?php echo $a ?>" />
                          </div>

                          <!-- Select specific roles -->
                          <div class="specific-roles-container get-specific-value mt-4 mb-5 d-none" data-specific-roles="<?php echo $a ?>" data-loop-number="<?php echo $a ?>">
                            <label class="form-label"><?php echo esc_html__( 'Função específica', 'staker-dynamic-price-rules' ); ?></label>
                            <select class="form-select specific-roles" name="advanced_condition[<?php echo $a ?>][specific_roles]" data-loop-count="<?php echo $a ?>">
                                <?php
                                $user_role_translations = array(
                                  'subscriber' => __( 'Assinante', 'staker-dynamic-price-rules' ),
                                  'editor' => __( 'Editor', 'staker-dynamic-price-rules' ),
                                  'author' => __( 'Autor', 'staker-dynamic-price-rules' ),
                                  'contributor' => __( 'Colaborador', 'staker-dynamic-price-rules' ),
                                  'administrator' => __( 'Administrador', 'staker-dynamic-price-rules' ),
                                  'customer' => __( 'Cliente', 'staker-dynamic-price-rules' ),
                                  'shop_manager' => __( 'Gerente de loja', 'staker-dynamic-price-rules' ),
                                );

                                $user_roles = wp_roles()->roles;

                                foreach ( $user_roles as $role_key => $role ) {
                                  $selected = ( esc_attr( $current_specific_role ) == $role_key ) ? "selected=selected" : "";
                                  $translated_role_name = isset( $user_role_translations[$role_key] ) ? $user_role_translations[$role_key] : $role['name'];
                                  
                                  echo '<option value="'. esc_attr( $role_key ) .'" '. $selected .'>'. esc_html( $translated_role_name ) .'</option>';
                                }
                                ?>
                            </select>
                          </div>
                          
                          <!-- Select specific products -->
                          <div class="specific-products get-specific-value mt-4 mb-5 d-none" data-loop-number="<?php echo $a ?>">
                              <label class="form-label"><?php echo esc_html__( 'Produtos específicos', 'staker-dynamic-price-rules' ) ?></label>
                              <div class="d-flex align-items-center ajax-search-with-loader" data-loop-number="<?php echo $a ?>">
                                  <input type="text" class="form-control product-search" data-loop-number="<?php echo $a ?>" placeholder="<?php echo esc_html__( 'Comece a digitar para pesquisar...', 'staker-dynamic-price-rules' ) ?>">
                                  <span class="spinner-border d-none"></span>
                              </div>
                              <div class="specific-product-results d-none" data-loop-number="<?php echo $a ?>">
                                  <ul id="product-results-<?php echo $a ?>" class="list-group list-itens-overflow"></ul>
                              </div>
                              <input type="hidden" name="advanced_condition[<?php echo $a ?>][specific_products]" value="<?php echo esc_attr( $current_specific_products ) ?>" data-save-specific-products="<?php echo $a ?>" />
                          </div>

                          <!-- Select specific categories -->
                          <div class="specific-categories get-specific-value mt-4 mb-5 d-none" data-loop-number="<?php echo $a ?>">
                            <label class="form-label"><?php echo esc_html__( 'Categorias específicas', 'staker-dynamic-price-rules' ) ?></label>
                            <div class="d-flex align-items-center ajax-search-with-loader" data-cat-loop-number="<?php echo $a ?>">
                              <input type="text" class="form-control category-search" data-cat-loop-number="<?php echo $a ?>" placeholder="<?php echo esc_html__( 'Comece a digitar para pesquisar...', 'staker-dynamic-price-rules' ) ?>">
                              <span class="spinner-border d-none"></span>
                            </div>
                            <div class="specific-category-results d-none" data-cat-loop-number="<?php echo $a ?>">
                                <ul id="category-results-<?php echo $a ?>" class="list-group list-itens-overflow"></ul>
                            </div>
                            <input type="hidden" name="advanced_condition[<?php echo $a ?>][specific_categories]" value="<?php echo esc_attr( $current_specific_categories ) ?>" data-save-specific-categories="<?php echo $a ?>"/>
                          </div>

                          <!-- Select specific attributes -->
                          <div class="specific-attributes get-specific-value mt-4 mb-5 d-none" data-loop-number="<?php echo $a ?>">
                            <label class="form-label"><?php echo esc_html__( 'Atributos específicos', 'staker-dynamic-price-rules' ) ?></label>
                            <div class="d-flex align-items-center ajax-search-with-loader" data-atr-loop-number="<?php echo $a ?>">
                                <input type="text" class="form-control attribute-search" data-atr-loop-number="<?php echo $a ?>" placeholder="<?php echo esc_html__( 'Comece a digitar para pesquisar...', 'staker-dynamic-price-rules' ) ?>">
                                <span class="spinner-border d-none"></span>
                            </div>
                            <div class="specific-attribute-results d-none" data-atr-loop-number="<?php echo $a ?>">
                                <ul id="attribute-results-<?php echo $a ?>" class="list-group list-itens-overflow"></ul>
                            </div>
                            <input type="hidden" name="advanced_condition[<?php echo $a ?>][specific_attributes]" value="<?php echo esc_attr( $current_specific_attributes ) ?>" data-save-specific-attributes="<?php echo $a ?>"/>
                          </div>

                          <!-- Condition for apply discounts -->
                          <div class="second-line-settings manage-discounts mt-4 mb-5 d-none" data-apply-discount-item="<?php echo $a ?>" data-loop-number="<?php echo $a ?>">
                            <label class="form-label"><?php echo esc_html__( 'Configure a aplicação do desconto', 'staker-dynamic-price-rules' ) ?></label>
                            <div class="input-group mb-3">
                              <select class="form-select discount-method" name="advanced_condition[<?php echo $a ?>][apply_discount_method]" data-loop-number="<?php echo $a ?>">
                                <option value="cart" <?php echo esc_attr( $current_apply_discount_method ) == 'cart' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Desconto no carrinho (Padrão)', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="quantity" <?php echo esc_attr( $current_apply_discount_method ) == 'quantity' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Desconto baseado em quantidade', 'staker-dynamic-price-rules' ) ?></option>
                              </select>

                              <input type="number" class="form-control border-right-0 min-qtd-aplly-discount d-none" name="advanced_condition[<?php echo $a ?>][min_qtd]" data-loop-number="<?php echo $a ?>" value="<?php echo esc_attr( $current_min_qtd_for_apply_discount) ?>" placeholder="<?php echo esc_html__( 'Quantidade mínima', 'staker-dynamic-price-rules' ) ?>"/>
                              
                              <select class="form-select select-middle-group" name="advanced_condition[<?php echo $a ?>][discount_method]">
                                <option value="percentage" <?php echo esc_attr( $current_discount_method ) == 'percentage' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Percentual (%)', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="fixed" <?php echo esc_attr( $current_discount_method ) == 'fixed' ? "selected=selected" : ""; ?>><?php echo sprintf( __( 'Valor fixo (%s)', 'staker-dynamic-price-rules' ), get_woocommerce_currency_symbol() ) ?></option>
                              </select>

                              <input type="number" class="form-control" name="advanced_condition[<?php echo $a ?>][discount_value]" value="<?php echo esc_attr( $current_discount_value ) ?>" placeholder="<?php echo esc_html__( 'Insira o valor de desconto', 'staker-dynamic-price-rules' ) ?>"/>
                            </div>
                          </div>

                          <!-- Condition for shipping method -->
                          <div class="second-line-settings manage-shipping mt-4 mb-5 d-none" data-shipping-method-item="<?php echo $a ?>" data-loop-number="<?php echo $a ?>">
                            <label class="form-label"><?php echo esc_html__( 'Forma de entrega', 'staker-dynamic-price-rules' ) ?></label>
                            <div class="input-group mb-3">
                              <select class="form-select set-payment-gateway-condition" name="advanced_condition[<?php echo $a ?>][shipping_method]">
                                  <option value="0"><?php esc_html_e('Selecione uma forma de entrega', 'staker-dynamic-price-rules'); ?></option>
                                  <?php $shipping_methods = WC()->shipping->get_shipping_methods();

                                  foreach ( $shipping_methods as $shipping_method ) {
                                      echo '<option value="' . esc_attr( $shipping_method->id ) . '" ' . ( esc_attr( $current_shipping_method ) ==  esc_attr( $shipping_method->id ) ? "selected=selected" : "" ) . '>' . esc_html( $shipping_method->method_title ) . '</option>';
                                  }
                                  ?>
                              </select>
                              <select class="form-select set-payment-gateway-condition" name="advanced_condition[<?php echo $a ?>][shipping_operator]">
                                <option value="0" <?php echo esc_attr( $current_shipping_operator ) == '0' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Selecione um operador', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="remove" <?php echo esc_attr( $current_shipping_operator ) == 'remove' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Remover', 'staker-dynamic-price-rules' ) ?></option>
                              </select>
                            </div>
                          </div>

                          <div class="third-line-settings manage-conditions text-left mt-4 mb-5">
                            <label class="form-label"><?php echo esc_html__( 'Configure as condições (Opcional)', 'staker-dynamic-price-rules' ) ?></label>
                            <div class="input-group mb-3">

                              <select class="form-select" name="advanced_condition[<?php echo $a ?>][apply_condition]">
                                <option value="0" <?php echo esc_attr( $current_apply_condition ) == '0' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Selecione um tipo de condição', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="cart_qtd_total" <?php echo esc_attr( $current_apply_condition ) == 'cart_qtd_total' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Quantidade total do carrinho', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="cart_value_total" <?php echo esc_attr( $current_apply_condition ) == 'cart_value_total' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Valor total do carrinho', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="user_level" <?php echo esc_attr( $current_apply_condition ) == 'user_level' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Nível do usuário', 'staker-dynamic-price-rules' ) ?></option>
                              </select>

                              <select class="form-select select-middle-group" name="advanced_condition[<?php echo $a ?>][operator_condition]">
                                <option value="0" <?php echo esc_attr( $current_operator_condition ) == '0' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Selecione um operador', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="less_than" <?php echo esc_attr( $current_operator_condition ) == 'less_than' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Menor que (<)', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="less_than_or_equal" <?php echo esc_attr( $current_operator_condition ) == 'less_than_or_equal' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Menor ou igual a (<=)', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="greater_than" <?php echo esc_attr( $current_operator_condition ) == 'greater_than' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Maior que (>)', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="greater_than_or_equal" <?php echo esc_attr( $current_operator_condition ) == 'greater_than_or_equal' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Maior ou igual a (>=)', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="equal" <?php echo esc_attr( $current_operator_condition ) == 'equal' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Igual (==)', 'staker-dynamic-price-rules' ) ?></option>
                                <option value="different" <?php echo esc_attr( $current_operator_condition ) == 'different' ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Diferente (!=)', 'staker-dynamic-price-rules' ) ?></option>
                              </select>

                              <input type="text" class="form-control" name="advanced_condition[<?php echo $a ?>][condition_value]" value="<?php echo esc_attr( $current_condition_value ) ?>" placeholder="<?php echo esc_html__( 'Insira o valor de condição', 'staker-dynamic-price-rules' ) ?>"/>
                            </div>
                          </div>

                          <div class="fourth-line-settings manage-limit mt-4 mb-3">
                            <label class="form-label mb-2"><?php echo esc_html__( 'Configure data e limite (Opcional)', 'staker-dynamic-price-rules' ) ?></label>
                            <div class="d-flex mt-3">
                              <div class="w-33 me-3">
                                <label class="form-label"><?php echo esc_html__( 'Limite de usos por usuário', 'staker-dynamic-price-rules' ) ?></label>
                                <input type="number" class="form-control" name="advanced_condition[<?php echo $a ?>][use_limit]" value="<?php echo esc_attr( $current_use_limit ) ?>" placeholder="<?php echo esc_html__( 'Insira o limite de uso', 'staker-dynamic-price-rules' ) ?>"/>
                              </div>
                              <div class="w-33 me-3">
                                <label class="form-label"><?php echo esc_html__( 'Data de início', 'staker-dynamic-price-rules' ) ?></label>
                                <input type="text" class="form-control date-start dateselect" name="advanced_condition[<?php echo $a ?>][start_date]" data-loop-number="<?php echo $a ?>" value="<?php echo esc_attr( $current_start_date ) ?>"/>
                              </div>
                              <div class="w-33">
                                <label class="form-label"><?php echo esc_html__( 'Data de finalização', 'staker-dynamic-price-rules' ) ?></label>
                                <input type="text" class="form-control date-end dateselect" name="advanced_condition[<?php echo $a ?>][end_date]" data-loop-number="<?php echo $a ?>" value="<?php echo esc_attr( $current_end_date ) ?>"/>
                              </div>
                            </div>
                          </div>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <button class="add-new-advanced-condition btn-add" title="<?php echo esc_html__( 'Adicionar nova condição', 'staker-dynamic-price-rules' ) ?>"></button>
              </div>
            </div>
        </td>
      </tr>
    </table>
</div>