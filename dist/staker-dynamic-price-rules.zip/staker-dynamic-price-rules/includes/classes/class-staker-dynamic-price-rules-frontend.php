<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class for manipulate actions on frontend
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Staker_Dynamic_Price_Rules_Frontend {
    
    /**
     * Construct function
     */
    public function __construct() {
        // set logout endpoint to last item menu account
        add_filter( 'woocommerce_account_menu_items', array( $this,  'reorganize_account_menu_items' ), 100 );

        $settings = get_option('staker-dynamic-price-rules-setting');

        // display price for logged users
        if ( isset( $settings['show_price_for_logged_users'] ) && $settings['show_price_for_logged_users'] == 'yes' && ! is_admin() ) {
            add_filter( 'woocommerce_get_price_html', array( $this, 'display_price_for_logged_user' ), 9999, 2 );
        }

        // display negotiate price
        if ( isset( $settings['enable_bargain_prices'] ) && $settings['enable_bargain_prices'] == 'yes' && ! is_admin() ) {
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_negotiate_price_scripts' ) );
            add_action( 'woocommerce_after_add_to_cart_form', array( $this, 'allow_user_negotiate_price' ) );
            add_action( 'woocommerce_cart_calculate_fees', array( $this, 'apply_discount_for_accepted_offer' ), 10, 1 );
        }
    }


    /**
     * Set to last item logout endpoint
     * 
     * @since 1.0.0
     * @param $items
     * @return string
     */
    public function reorganize_account_menu_items( $items ) {
        // Remove the "Log out account" endpoint
        if ( isset( $items['customer-logout'] ) ) {
            unset( $items['customer-logout'] );
        }
    
        // Add the log out endpoint again
        $items = $items + array( 'customer-logout' => __('Sair da conta', 'woocommerce') );
    
        return $items;
    }


    /**
     * Display price for logged users if option is active
     * 
     * @since 1.0.0
     * @param $price
     * @param $product
     * @return string
     */
    public function display_price_for_logged_user( $price, $product ) {
        if ( ! is_user_logged_in() ) { 
           $price = '<div><a class="require-login-for-display-price" href="' . get_permalink( wc_get_page_id( 'myaccount' ) ) . '">' . __( 'Entre em sua conta para ver o preço', 'staker-dynamic-price-rules' ) . '</a></div>';
           remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
           remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
           add_filter( 'woocommerce_is_purchasable', '__return_false' );
        }

        return $price;
    }


    /**
	 * Include scripts for negotiate price
     * 
     * @since 1.0.0
     * @return void
	 */
	public function enqueue_negotiate_price_scripts() {
        if ( !is_product() ) {
            return;
        }

		wp_enqueue_script( 'sdpr-negotiate-price', STAKER_DYNAMIC_PRICE_RULES_ASSETS_URL . 'front/js/negotiate-price.js', array('jquery'), STAKER_DYNAMIC_PRICE_RULES_VERSION );
        wp_enqueue_style( 'sdpr-negotiate-price-styles', STAKER_DYNAMIC_PRICE_RULES_ASSETS_URL . 'front/css/negotiate-price-styles.css', array(), STAKER_DYNAMIC_PRICE_RULES_VERSION );
	
        wp_localize_script( 'sdpr-negotiate-price', 'sdpr_np_params', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
        ));
    }


    /**
     * Allow user negotiate product price
     * 
     * @since 1.0.0
     * @return void
     */
    public function allow_user_negotiate_price() {
        if ( !is_product() ) {
            return;
        }

        global $product;

        if ( is_user_logged_in() ) {
            $user_id = get_current_user_id();
            $product_id = $product->get_id();
            $get_product_price = $product->get_price(); ?>

            <a href="#" class="negotiate-price-trigger" data-product-id="<?php echo $product_id; ?>"><?php echo esc_html__('Negociar preço', 'staker-dynamic-price-rules') ?></a>

            <div id="negotiate-popup-<?php echo $product_id; ?>" class="negotiate-popup">
                <div class="negotiate-popup-content">
                    <div class="negotiate-popup-header">
                        <h3><?php echo esc_html__('Negociar preço', 'staker-dynamic-price-rules') ?></h3>
                        <button class="close-negotiate-popup btn-close" class="btn-close fs-lg" aria-label="Fechar"></button>
                    </div>
                    <form action="" method="post" name="send-negotiate-product-price">
                        <div>
                            <p class="current-product-price"><?php echo sprintf( __('Preço atual: %s', 'staker-dynamic-price-rules'), wc_price( $get_product_price ) ); ?></p>
                            <input type="hidden" name="sdpr_user_id" value="<?php echo $user_id; ?>">
                            <input type="hidden" name="sdpr_product_id" value="<?php echo $product_id; ?>">
                            <label for="negotiated_price"><?php echo esc_html__('Preço desejado', 'staker-dynamic-price-rules') ?></label>
                            <div class="offer-price">
                                <span class="currency"><?php echo get_woocommerce_currency_symbol(); ?></span>
                                <input type="text" class="input-outline-primary" name="negotiated_price" id="negotiated_price" required>
                                <button type="submit" class="send-offer button-primary"><?php echo esc_html__('Enviar oferta', 'staker-dynamic-price-rules') ?></button>
                            </div>
                            <div class="offer-notification">
                                <div class="alert d-flex alert-success d-none" role="alert">
                                    <span><?php echo esc_html__('Oferta enviada com sucesso', 'staker-dynamic-price-rules') ?></span>
                                </div>
                                <div class="alert d-flex alert-danger d-none" role="alert">
                                <span><?php echo esc_html__('Ocorreu um erro ao enviar a oferta', 'staker-dynamic-price-rules') ?></span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php
        } else {
            ?>
            <div class="require-login-for-negotiate-price">
                <span class="negotiate-price-message"><?php echo esc_html__('Faça login para fazer uma oferta', 'staker-dynamic-price-rules') ?></span>
            </div>
            <?php
        }
    }


    /**
     * Apply discount to cart when offer is accepted
     * 
     * @since 1.0.0
     * @param $cart
     * @return void
     */
    public function apply_discount_for_accepted_offer( $cart ) {
        $get_offers = get_option('prices_negotiated_by_users', array());
    
        // Checks if the cart is empty, if there are offers or if you are an administrator without AJAX action
        if ( empty( $cart ) || empty( $get_offers ) || ( is_admin() && ! defined( 'DOING_AJAX' ) ) ) {
            return;
        }
    
        $user_id = get_current_user_id();
        $discount_total = 0;
    
        foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
            $product_id = $cart_item['product_id'];
            $quantity = $cart_item['quantity'];
    
            // Checks if there is an offer accepted by the user for this product
            foreach ( $get_offers as $offer ) {
                if ( $offer['user_id'] == $user_id && $offer['product_id'] == $product_id && isset( $offer['status'] ) && $offer['status'] === 'accepted' ) {
                    $negociated_price = floatval( str_replace(',', '.', $offer['negotiated_price']) );
                    
                    // Gets the price of the product in the cart, including discounts already applied
                    $product_price = floatval( $cart_item['data']->get_price() );
                    
                    // Calculates the discount based on the price of the product in the cart
                    $discounted_item = ( $product_price - $negociated_price) * $quantity;
                    $discount_total += $discounted_item;
                }
            }
        }
    
        // apply discount
        if ( $discount_total > 0 ) {
            $cart->add_fee( __( 'Desconto de oferta', 'staker-dynamic-price-rules' ), -$discount_total );
        }
    }
}

new Staker_Dynamic_Price_Rules_Frontend();