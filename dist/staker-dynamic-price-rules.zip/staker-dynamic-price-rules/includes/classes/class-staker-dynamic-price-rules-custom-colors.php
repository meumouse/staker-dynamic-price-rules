<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Change colors on front-end
 *
 * @package MeuMouse.com
 * @since 1.0.0
 */

class Staker_Dynamic_Price_Rules_Custom_Colors extends Staker_Dynamic_Price_Rules_Init {

  public function __construct() {
    parent::__construct();

    add_action( 'wp_head', array( $this, 'staker_dynamic_price_rules_custom_styles' ) );
  }

  /**
   * Custom color primary
   * 
   * @return string
   * @since 1.0.0
   */
  public function staker_dynamic_price_rules_custom_styles() {
    $primary_color = $this->getSetting( 'set_primary_color' );
    $hover_color = $this->generate_rgba_color($primary_color, 80);
  
    $css = '.button-primary {';
      $css .= 'background-color:'. $primary_color .' !important;';
      $css .= 'border-color:'. $primary_color .' !important;';
    $css .= '}';

    $css .= '.button-primary:hover {';
      $css .= 'background-color:'. $hover_color .' !important;';
      $css .= 'border-color:'. $hover_color .' !important;';
    $css .= '}';

    $css .= '.input-outline-primary:focus {';
      $css .= 'border-color:'. $hover_color .' !important;';
    $css .= '}';


    ?>
    <style type="text/css">
      <?php echo $css; ?>
    </style> <?php
  }


  /**
   * Generate RGBA color from primary color
   * 
   * @since 1.0.0
   * @return string
   * @package MeuMouse.com
   */
  public function generate_rgba_color($color, $opacity) {
    // removes the "#" character if present 
    $color = str_replace("#", "", $color);

    // gets the RGB decimal value of each color component
    $red = hexdec(substr($color, 0, 2));
    $green = hexdec(substr($color, 2, 2));
    $blue = hexdec(substr($color, 4, 2));
    $opacity = $opacity / 100;

    // generates RGBA color based on foreground color and opacity
    $rgba_color = "rgba($red, $green, $blue, $opacity)";

    return $rgba_color;
  }

}

new Staker_Dynamic_Price_Rules_Custom_Colors();