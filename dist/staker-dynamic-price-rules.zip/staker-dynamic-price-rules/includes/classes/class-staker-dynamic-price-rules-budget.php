<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class for budget feature
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Staker_Dynamic_Price_Rules_Budget {

    public function __construct() {
        // register budget endpoint
        add_action( 'init', array( $this, 'register_budgets_endpoint' ) );

        // register budget view details endpoint
        add_action( 'init', array( $this, 'register_budget_view_details_endpoint' ) );

        // add tab on WooCommerce menu items
        add_filter( 'woocommerce_account_menu_items', array( $this, 'add_tab_menu_item_budgets' ) );

        // enqueue scripts
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_budget_scripts' ) );

        // load template content on page
        add_action( 'woocommerce_account_budgets_endpoint', array( $this, 'load_content_budgets_page_user' ) );

        // create budget content page
        add_action( 'sdpr_budget_content_details', array( $this, 'load_budget_details_content' ) );

        // create endpoint for handle ajax callers
        add_action( 'wp_ajax_send_budget', array( $this, 'send_budget_action_callback' ) );
        add_action( 'wp_ajax_nopriv_send_budget', array( $this, 'send_budget_action_callback' ) );

        // customer aprovation action
        add_action( 'wp_ajax_customer_aprovation', array( $this, 'customer_aprovation_action_callback' ) );
        add_action( 'wp_ajax_nopriv_customer_aprovation', array( $this, 'customer_aprovation_action_callback' ) );

        // add query vars for load budget id
        add_action( 'woocommerce_get_query_vars', array( $this,  'add_budget_id_query_vars' ) );

        // add template page for view each budget
        add_action( 'template_redirect', array( $this, 'add_template_for_budgets' ) );
    }
    

    /**
     * Register endpoint
     * 
     * @since 1.0.0
     */
    public function register_budgets_endpoint() {
        add_rewrite_endpoint( 'budgets', EP_ROOT | EP_PAGES );

        // update permalinks
        flush_rewrite_rules();
    }


    /**
     * Register budget view details endpoint
     * 
     * @since 1.0.0
     */
    public function register_budget_view_details_endpoint() {
        add_rewrite_rule('^my-account/budgets/view-budget/([^/]+)/?', 'index.php?pagename=my-account&budget_id=$matches[1]', 'top');
    }


    /**
     * Add tab on WooCommerce menu items
     * 
     * @since 1.0.0
     * @param $items
     * @return array
     */
    public function add_tab_menu_item_budgets( $items ) {
        $items['budgets'] = __( 'Orçamentos', 'staker-dynamic-price-rules' );

        return $items;
    }


    /**
	 * Include scripts for budget actions
     * 
     * @since 1.0.0
     * @return void
	 */
	public function enqueue_budget_scripts() {
        global $wp;

        if ( isset( $wp->query_vars['budgets'] ) ) {
            wp_enqueue_script( 'sdpr-budgets', STAKER_DYNAMIC_PRICE_RULES_ASSETS_URL . 'front/js/budgets.js', array('jquery'), STAKER_DYNAMIC_PRICE_RULES_VERSION );
            wp_enqueue_style( 'sdpr-budgets-styles', STAKER_DYNAMIC_PRICE_RULES_ASSETS_URL . 'front/css/budgets-styles.css', array(), STAKER_DYNAMIC_PRICE_RULES_VERSION );
        
            wp_localize_script( 'sdpr-budgets', 'sdpr_budgets_params', array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
            ));
        }
    }


    /**
     * Load content on budgets endpoint
     * 
     * @since 1.0.0
     * @return void
     */
    public function load_content_budgets_page_user() {
        if ( is_user_logged_in() ) {
            $user_id = get_current_user_id();
            $user_data = get_userdata( $user_id );
            $options = get_option('staker-dynamic-price-rules-setting');
            
            // display user created budgets
            $this->display_user_budgets_table(); ?>

            <button class="sdpr-budget-popup-trigger button-primary"><?php echo esc_html__( 'Criar um novo orçamento', 'staker-dynamic-price-rules' ) ?></button>

            <div class="sdpr-budget-container">
                <div class="sdpr-budget-content">
                    <div class="sdpr-budget-header">
                        <h5 class="sdpr-popup-title"><?php echo esc_html__( 'Criar um novo orçamento', 'staker-dynamic-price-rules' ); ?></h5>
                        <button class="sdpr-close-budget-popup btn-close fs-lg" aria-label="Fechar"></button>
                    </div>
                    <form method="post" name="sdpr-send-budget">

                        <?php if ( isset( $options['enable_name_field'] ) && $options['enable_name_field'] == 'yes' && isset( $options['enable_lastname_field'] ) && $options['enable_lastname_field'] == 'no' ) {
                            ?>
                            <p class="form-row-wide">
                                <label class="form-label" for="budget_first_name"><?php _e( 'Nome completo', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="text" class="form-control" name="budget_name_and_last_name" id="budget_name_and_last_name" value="<?php echo esc_attr( $user_data->first_name, $user_data->last_name ); ?>" required />
                            </p>
                            <?php
                        } else {
                            ?>
                            <p class="form-row-first">
                                <label class="form-label" for="budget_first_name"><?php _e( 'Nome', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="text" class="form-control" name="budget_first_name" id="budget_first_name" value="<?php echo esc_attr( $user_data->first_name ); ?>" required />
                            </p>
                            <?php
                        }
                        
                        // check if last name field is active
                        if ( isset( $options['enable_lastname_field'] ) && $options['enable_lastname_field'] == 'yes' ) {
                            ?>
                            <p class="form-row-last">
                                <label class="form-label" for="budget_last_name"><?php _e( 'Sobrenome', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="text" class="form-control" name="budget_last_name" id="budget_last_name" value="<?php echo esc_attr( $user_data->last_name ); ?>" required />
                            </p>
                            <?php
                        }

                        // if person type is both
                        if ( isset( $options['set_person_type_method'] ) && $options['set_person_type_method'] === 'cpf_and_cnpj' ) {
                            ?>
                            <p class="">
                                <label class="form-label" for="budget_person_type"><?php _e( 'Tipo de Pessoa', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <select class="form-select" name="budget_person_type" id="budget_person_type" required>
                                    <option value="cpf_field"><?php _e( 'Pessoa Física (CPF)', 'staker-dynamic-price-rules' ); ?></option>
                                    <option value="cnpj_field"><?php _e( 'Pessoa Jurídica (CNPJ)', 'staker-dynamic-price-rules' ); ?></option>
                                </select>
                            </p>
                            <p class="cpf-field d-none">
                                <label class="form-label" for="budget_cpf_field"><?php _e( 'CPF', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="text" class="form-control" name="budget_cpf_field" id="budget_cpf_field" value="" required />
                            </p>
                            <p class="cnpj-field d-none">
                                <label class="form-label" for="budget_cnpj_field"><?php _e( 'CNPJ', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="text" class="form-control" name="budget_cnpj_field" id="budget_cnpj_field" value="" required />
                            </p>
                            <?php
                        }

                        // if person type is cpf only
                        if ( isset( $options['set_person_type_method'] ) && $options['set_person_type_method'] === 'cpf_only' ) {
                            ?>
                            <p class="">
                                <label class="form-label" for="budget_cpf_field"><?php _e( 'CPF', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="text" class="form-control" name="budget_cpf_field" id="budget_cpf_field" value="" required />
                            </p>
                            <?php
                        }

                        // if person type is cnpj only
                        if ( isset( $options['set_person_type_method'] ) && $options['set_person_type_method'] === 'cnpj_only' ) {
                            ?>
                            <p class="">
                                <label class="form-label" for="budget_cnpj_field"><?php _e( 'CNPJ', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="text" class="form-control" name="budget_cnpj_field" id="budget_cnpj_field" value="" required />
                            </p>
                            <?php
                        }

                        // check if social reason field is active
                        if ( isset( $options['enable_social_reason_field'] ) && $options['enable_social_reason_field'] === 'yes' ) {
                            ?>
                            <p class="social-reason-field d-none">
                                <label class="form-label" for="budget_social_reason_field"><?php _e( 'Razão social', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="text" class="form-control" name="budget_social_reason_field" id="budget_social_reason_field" value="" required />
                            </p>
                            <?php
                        }

                        // check if phone field is active
                        if ( isset( $options['enable_phone_field'] ) && $options['enable_phone_field'] === 'yes' ) {
                            ?>
                            <p class="">
                                <label class="form-label" for="budget_phone_field"><?php _e( 'Telefone', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="tel" class="form-control" name="budget_phone_field" id="budget_phone_field" value="<?php echo esc_attr( get_user_meta( $user_id, 'billing_phone', true ) ); ?>" required />
                            </p>
                            <?php
                        }

                        // check if email field is active
                        if ( isset( $options['enable_email_field'] ) && $options['enable_email_field'] === 'yes' ) {
                            ?>
                            <p class="">
                                <label class="form-label" for="budget_email_field"><?php _e( 'E-mail', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="email" class="form-control" name="budget_email_field" id="budget_email_field" value="<?php echo esc_attr( $user_data->user_email ); ?>" required />
                            </p>
                            <?php
                        }

                        // check if service type field is active
                        if ( isset( $options['enable_type_service_field'] ) && $options['enable_type_service_field'] === 'yes' ) {
                            ?>
                            <p class="">
                                <label class="form-label" for="budget_service_type_field"><?php _e( 'Tipo do produto/serviço', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="text" class="form-control" name="budget_service_type_field" id="budget_service_type_field" value="" required />
                            </p>
                            <?php
                        }

                        // check if deadline field is active
                        if ( isset( $options['enable_deadline_field'] ) && $options['enable_deadline_field'] === 'yes' ) {
                            ?>
                            <p class="">
                                <label class="form-label" for="budget_deadline_field"><?php _e( 'Prazo máximo para execução do produto/serviço em dias úteis', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <input type="number" class="form-control" name="budget_deadline_field" id="budget_deadline_field" value="" required />
                            </p>
                            <?php
                        }

                        // check if aditional info field is active
                        if ( isset( $options['enable_aditional_info_field'] ) && $options['enable_aditional_info_field'] === 'yes' ) {
                            ?>
                            <p class="">
                                <label class="form-label" for="budget_aditional_info_field"><?php _e( 'Informações adicionais para execução do produto/serviço', 'staker-dynamic-price-rules' ); ?> <span class="required">*</span></label>
                                <textarea class="form-control" name="budget_aditional_info_field" id="budget_aditional_info_field" value="" required></textarea>
                            </p>
                            <?php
                        }
                        
                        ?>

                        <p class="send-budget-container">
                            <button type="submit" class="button-primary mt-2" name="create_new_budget"><?php esc_html_e( 'Solicitar orçamento', 'staker-dynamic-price-rules' ); ?></button>
                            <input type="hidden" name="send_new_budget" value="" />
                            <div class="budget-notification">
                                <div class="alert alert-success d-none" role="alert">
                                    <span><?php echo esc_html__('Orçamento enviado com sucesso!', 'staker-dynamic-price-rules') ?></span>
                                </div>
                                <div class="alert alert-danger d-none" role="alert">
                                    <span><?php echo esc_html__('Ocorreu um erro ao enviar o orçamento. Tente novamente.', 'staker-dynamic-price-rules') ?></span>
                                </div>
                            </div>
                        </p>
                    </form>
                </div>
            </div>
            <?php
        }
    }


    /**
     * Display created budgets for user
     * 
     * @since 1.0.0
     * @return void
     */
    public function display_user_budgets_table() {
        if ( is_user_logged_in() ) {
            $user_id = get_current_user_id();
            $user_budgets = get_option( 'staker_dynamic_price_rules_user_budgets', array() );
            $user_budgets = maybe_unserialize( $user_budgets );

            // filter budgets that exists id and creation date 
            $budgets = array_filter( $user_budgets, function( $budget ) {
                return isset( $budget['id']) && isset( $budget['creation_date']);
            });

            foreach ( $budgets as $budget ) {
                $current_value = $budget['value'];
            }
    
            if ( ! empty( $budgets ) ) {
                echo '<h2>'. __( 'Meus orçamentos', 'staker-dynamic-price-rules' ) .'</h2>';
                echo '<table>';
                    echo '<thead>';
                        echo '<tr>';
                        echo '<th>'. __( 'Orçamento', 'staker-dynamic-price-rules' ) .'</th>';
                        echo '<th>'. __( 'Criado em', 'staker-dynamic-price-rules' ) .'</th>';
                        echo '<th>'. __( 'Status', 'staker-dynamic-price-rules' ) .'</th>';
                        echo '<th>'. __( 'Valor', 'staker-dynamic-price-rules' ) .'</th>';
                        echo '<th>'. __( 'Ação', 'staker-dynamic-price-rules' ) .'</th>';
                        echo '</tr>';
                    echo '</thead>';
                echo '<tbody>';
    
                foreach ( $budgets as $budget ) {
                    if ( is_array( $budget ) && isset( $budget['user_id'] ) && $budget['user_id'] == $user_id ) {
                        $status = $budget['status'];

                        echo '<tr>';
                        echo '<td><a class="budget-id" target="_blank" href="' . esc_url( get_permalink( wc_get_page_id('myaccount') ) . 'budgets/view-budget/' . $budget['id'] . '/?token=' . $budget['token'] ) . '">'. sprintf( __( '#%s', 'staker-dynamic-price-rules' ), $budget['id'] ) .'</a></td>';
                        echo '<td><span class="get-budget-creatin-date">' . esc_html( $budget['creation_date'] ) . '</span></td>';
                        echo '<td>';
                            echo '<span class="get-budget-status '. $status .'">';
                                if ( $status === 'pending' ) {
                                    echo __( 'Pendente', 'staker-dynamic-price-rules' );
                                } elseif ( $status === 'in-progress' ) {
                                    echo __( 'Em andamento', 'staker-dynamic-price-rules' );
                                } elseif ( $status === 'cancelled' ) {
                                    echo __( 'Cancelado', 'staker-dynamic-price-rules' );
                                } elseif ( $status === 'completed' ) {
                                    echo __( 'Concluído', 'staker-dynamic-price-rules' );
                                }
                            echo '</span>';
                        echo '</td>';
                        echo '<td>';
                            echo '<span class="get-budget-value">';
                                if ( (int)$budget['value'] === 0 ) {
                                    echo __( 'Aguardando', 'staker-dynamic-price-rules' );
                                } else {
                                    echo wc_price( $budget['value'] );
                                }
                            echo '</span>';
                        echo '</td>';

                        if ( (int)$budget['value'] !== 0 ) {
                            echo '<td class="customer-aprovation">';
                                echo '<form method="post" name="sdpr_decline_budget">';
                                    echo '<button class="decline-budget button-secondary" data-budget-id="'. $budget['id'] .'" data-customer-approval="declined">'. __( 'Recusar', 'staker-dynamic-price-rules' ) .'</button>';
                                echo '</form>';
                                echo '<form method="post" name="sdpr_approve_budget">';
                                    echo '<button class="approve-budget button-success" data-budget-id="'. $budget['id'] .'" data-customer-decline="approved">'. __( 'Aceitar', 'staker-dynamic-price-rules' ) .'</button>';
                                echo '</form>';
                            echo '</td>';
                        } else {
                            echo '<td><a class="view-budget" target="_blank" href="' . esc_url( get_permalink( wc_get_page_id('myaccount') ) . 'budgets/view-budget/' . $budget['id'] . '/?token=' . $budget['token'] ) . '">'. __( 'Ver orçamento', 'staker-dynamic-price-rules' ) .'</a></td>';
                        }
                        
                        echo '</tr>';
                    }
                }
                echo '</tbody>';
                echo '</table>';
            } else {
                echo '<p class="empty-user-budgets">' . esc_html__( 'Você ainda não tem orçamentos.', 'staker-dynamic-price-rules' ) . '</p>';
            }
        }
    }    


    /**
     * Add token on URL for access budgets without login
     * 
     * @since 1.0.0
     * @param $query_vars
     * @return string
     */
    public function add_budget_id_query_vars( $query_vars ) {
        $query_vars[] = 'budget_id';
        $query_vars[] = 'token';

        return $query_vars;
    }


    /**
     * Add template page for each budgets
     * 
     * @since 1.0.0
     * @return void
     */
    public function add_template_for_budgets() {
        if ( is_page('my-account') && get_query_var('budget_id') && get_query_var('token') ) {
            $budget_id = get_query_var('budget_id');
            $query_token = get_query_var('token');
            $user_budgets = get_option('staker_dynamic_price_rules_user_budgets', array());
            $user_budgets = maybe_unserialize( $user_budgets );
            $user_budget = null;

            foreach ( $user_budgets as $budget ) {
                if ( is_array( $budget ) && isset( $budget['id'] ) && $budget['id'] == $budget_id ) {
                    $user_budget = $budget;
                    $token = $budget['token'];
                    break;
                }
            }

            // check if query token is equal to token from budget
            if ( $budget['id'] !== $budget_id && $token !== $query_token ) {
                wp_redirect( get_permalink( wc_get_page_id('myaccount') ) . '/budgets/', 302 );
            }
    
            if ( $user_budget && !empty( $token ) ) {
                include_once STAKER_DYNAMIC_PRICE_RULES_INC_DIR . 'templates/my-account/view-budget.php';
                exit;
            } else {
                wp_redirect( get_permalink( wc_get_page_id('myaccount') ) . '/budgets/', 302 );
                exit;
            }
        }
    }


    /**
     * Load  budget details content in custom hook
     * 
     * @since 1.0.0
     * @return void
     */
    public function load_budget_details_content() {
        $id = get_query_var('budget_id');
        $options = get_option('staker-dynamic-price-rules-setting');
        $get_logo = $options['display_logo_budgets'];
        $user_budgets = get_option('staker_dynamic_price_rules_user_budgets', array());
        $user_budgets = maybe_unserialize( $user_budgets );

        $budget_id = $user_budgets[$id]['id'];
        $creation_date = $user_budgets[$id]['creation_date'];
        $user_email = $user_budgets[$id]['user_email'];
        $current_status = $user_budgets[$id]['status'];
        $customer_aprovation = $user_budgets[$id]['customer_aprovation'];
        $budget_value = $user_budgets[$id]['value'];
        $full_name = $user_budgets[$id]['full_name'];
        $first_name = $user_budgets[$id]['first_name'];
        $last_name = $user_budgets[$id]['last_name'];
        $phone_number = $user_budgets[$id]['phone_number'];
        $person_type = $user_budgets[$id]['person_type'];
        $pf_person = $user_budgets[$id]['pf_person'];
        $pj_person = $user_budgets[$id]['pj_person'];
        $social_reason = $user_budgets[$id]['social_reason'];
        $service_type = $user_budgets[$id]['service_type'];
        $service_deadline = $user_budgets[$id]['service_deadline'];
        $aditional_info = $user_budgets[$id]['aditional_info'];
        $budget_details = $user_budgets[$id]['details'];
        $aditional_info_admin = $user_budgets[$id]['aditional_info_admin'];
        $start_date = $user_budgets[$id]['start_date'];
        $end_date = $user_budgets[$id]['end_date'];

        ?>

        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php echo sprintf( __( 'Orçamento %s', 'staker-dynamic-price-rules' ), $budget_id ) ?></title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        </head>

        <div class="container py-5">
            <div class="d-flex justify-content-center mb-5">
                <a href="<?php echo get_home_url() ?>" target="_self">
                    <img class="budget-logo" src="<?php echo $get_logo ?>"/>
                </a>
            </div>
            <div class="customer-aprovation mb-4">
                <?php
                if ( $customer_aprovation === 'approved' ) {
                    echo '<span class="badge bg-success-subtle text-success py-2 px-3 rounded-pill">'. __( 'Aceito', 'staker-dynamic-price-rules' ) .'</span>';
                } elseif ( $customer_aprovation === 'declined' ) {
                    echo '<span class="badge bg-danger-subtle text-danger py-2 px-3 rounded-pill">'. __( 'Recusado', 'staker-dynamic-price-rules' ) .'</span>';
                } elseif ( $customer_aprovation === 'pending' ) {
                    echo '<span class="badge bg-warning-subtle text-warning py-2 px-3 rounded-pill">'. __( 'Aguardando resposta', 'staker-dynamic-price-rules' ) .'</span>';
                }
                ?>
            </div>
            <div class="border rounded-3 bg-white d-flex p-5 justify-content-center">
                <div class="col-10">
                    <div class="d-flex mb-4">
                        <div>
                            <span class="fs-5 fw-semibold"><?php echo sprintf( __( 'Orçamento #%s', 'staker-dynamic-price-rules' ), esc_html( $budget_id ) ); ?></span>
                            <p class="fs-sm text-muted"><?php echo sprintf( __( 'Criado em: %s', 'staker-dynamic-price-rules' ), esc_html( $creation_date ) ); ?></p>
                        </div>
                    </div>
                    <div class="d-flex mb-4">
                        <div class="mt-4 d-grid col-lg-6 me-4">
                            <span class="fw-semibold"><?php echo $options['text_social_reason_budget_header'] ?></span>
                            <span class="text-muted"><?php echo $options['text_cnpj_budget_header'] ?></span>
                            <span class="text-muted"><?php echo $options['text_address_budget_header'] ?></span>
                        </div>
                        <div class="mt-4 d-grid col-lg-6">
                            <div class="d-flex">
                                <p class="prefix-client me-1 mb-1"><?php echo __( 'Cliente:', 'staker-dynamic-price-rules' ); ?></p>
                                <?php
                                if ( isset( $options['enable_name_field'] ) && $options['enable_name_field'] == 'yes' && isset( $options['enable_lastname_field'] ) && $options['enable_lastname_field'] == 'no' ) {
                                    ?>
                                    <p class="full-name"><?php echo esc_html( $full_name ); ?></p>
                                    <?php
                                } else {
                                    ?>
                                    <p class="first-and-last-name"><?php echo sprintf( __( '%s %s', 'staker-dynamic-price-rules' ), esc_html( $first_name ), esc_html( $last_name ) ); ?></p>
                                    <?php
                                }
                                ?>
                            </div>
                            <?php
                            if ( $person_type === 'cpf_field' ) {
                                ?>
                                <p class="mb-1"><?php echo sprintf( __( 'CPF: %s', 'staker-dynamic-price-rules' ), esc_html( $pf_person ) ); ?></p>
                                <?php
                            } else {
                                ?>
                                <p class="mb-1"><?php echo sprintf( __( 'CNPJ: %s', 'staker-dynamic-price-rules' ), esc_html( $pj_person ) ); ?></p>
                                <p class="mb-1"><?php echo sprintf( __( 'Razão social: %s', 'staker-dynamic-price-rules' ), esc_html( $social_reason ) ); ?></p>
                                <?php
                            }
                            ?>
                            <p class="mb-1"><?php echo sprintf( __( 'Telefone: %s', 'staker-dynamic-price-rules' ), esc_html( $phone_number ) ); ?></p>
                            <p class="mb-1"><?php echo sprintf( __( 'E-mail: %s', 'staker-dynamic-price-rules' ), esc_html( $user_email ) ); ?></p>
                        </div>   
                    </div>
                    <div class="mb-4 border-top pt-5">
                        <p class="text-left d-block fw-semibold"><?php echo __( 'Descrição:', 'staker-dynamic-price-rules' ); ?></p>
                        <p class="mb-1"><?php echo $budget_details ?></p>
                    </div>
                    <div class="mb-4">
                        <p class="text-left d-block fw-semibold"><?php echo __( 'Observações:', 'staker-dynamic-price-rules' ); ?></p>
                        <p class="mb-1"><?php echo $aditional_info_admin ?></p>
                    </div>
                    <div class="border-top pt-5">
                        <p class="mb-1"><?php echo sprintf( esc_html( 'Data de início: %s', 'staker-dynamic-price-rules' ), $start_date ) ?></p>
                        <p class="mb-3"><?php echo sprintf( esc_html( 'Data de finalização: %s', 'staker-dynamic-price-rules' ), $end_date ) ?></p>
                        <div class="d-flex align-items-center">
                            <p class="text-muted me-2 mb-0"><?php echo __( 'Valor:', 'staker-dynamic-price-rules' ); ?></p>
                            <div class="input-group">
                                <span class="input-group-text text-muted"><?php echo get_woocommerce_currency_symbol(); ?></span>
                                <span class="input-group-text"><?php echo $budget_value; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        $css = 'body {';
            $css .= 'background-color: #F8F9FA !important;';
            $css .= 'font-family: Inter,sans-serif !important;';
        $css .= '}';

        $css .= '.budget-logo {';
            $css .= 'width: 12rem;';
        $css .= '}';

        $css .= '.budget-logo:hover {';
            $css .= 'opacity: 0.75;';
        $css .= '}';

        $css .= '.fs-sm {';
            $css .= 'font-size: 0.875rem !important;';
        $css .= '}';

        ?>
        <style type="text/css">
        <?php echo $css; ?>
        </style> <?php
    }


    /**
     * Send budget action for user
     * 
     * @since 1.0.0
     * @return void
     */
    public function send_budget_action_callback() {
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
            $budget_data = $_POST;
            $token = bin2hex(random_bytes(16));
            $budget_data['token'] = $token;
            $user_id = get_current_user_id();
            $budget_data['user_id'] = $user_id;
            $user_data = get_userdata($user_id);
            $budget_data['user_email'] = $user_data->user_email;
            $budget_id = $this->get_next_budget_id();
            $budget_data['id'] = $budget_id;
            $timezone = get_option('timezone_string');
            date_default_timezone_set($timezone);
            $date_format = get_option('date_format');
            $current_date = date($date_format);
    
            $user_budgets = get_option('staker_dynamic_price_rules_user_budgets', array());
            $user_budgets = maybe_unserialize($user_budgets);
    
            // Use o ID do orçamento como chave associativa
            $user_budgets[$budget_id] = array(
                'id' => $budget_data['id'],
                'token' => $budget_data['token'],
                'creation_date' => $current_date,
                'status' => isset( $budget_data['status'] ) ? $budget_data['status'] : 'pending',
                'value' => isset( $budget_data['value'] ) ? $budget_data['value'] : 0,
                'full_name' => isset( $budget_data['budget_name_and_last_name'] ) ? $budget_data['budget_name_and_last_name'] : '',
                'first_name' => isset( $budget_data['budget_first_name'] ) ? $budget_data['budget_first_name'] : '',
                'last_name' => isset( $budget_data['budget_last_name'] ) ? $budget_data['budget_last_name'] : '',
                'person_type' => isset( $budget_data['budget_person_type'] ) ? $budget_data['budget_person_type'] : '',
                'pf_person' => isset( $budget_data['budget_cpf_field'] ) ? $budget_data['budget_cpf_field'] : '',
                'pj_person' => isset( $budget_data['budget_cnpj_field'] ) ? $budget_data['budget_cnpj_field'] : '',
                'social_reason' => isset( $budget_data['budget_social_reason_field'] ) ? $budget_data['budget_social_reason_field'] : '',
                'user_id' => $budget_data['user_id'],
                'user_email' => $budget_data['user_email'],
                'phone_number' => isset( $budget_data['budget_phone_number'] ) ? $budget_data['budget_phone_number'] : '',
                'service_type' => isset( $budget_data['budget_service_type'] ) ? $budget_data['budget_service_type'] : '',
                'service_deadline' => isset( $budget_data['budget_deadline'] ) ? $budget_data['budget_deadline'] : '',
                'aditional_info' => isset( $budget_data['budget_aditional_info'] ) ? $budget_data['budget_aditional_info'] : '',
                'customer_aprovation' => isset( $budget_data['customer_aprovation'] ) ? $budget_data['customer_aprovation'] : 'pending',
            );
    
            update_option('staker_dynamic_price_rules_user_budgets', $user_budgets);
    
            // Envie um e-mail para o administrador
            $admin_email = get_option('admin_email');
            $subject = __('Parabéns! Você recebeu um novo orçamento!', 'staker-dynamic-price-rules');
            $message = sprintf(__('Um novo orçamento foi criado por %s. Detalhes do orçamento:<br><br>%s', 'staker-dynamic-price-rules'), $user_data->first_name . ' ' . $user_data->last_name, print_r($budget_data, true));
            $headers = array('Content-Type: text/html; charset=UTF-8');
    
            wp_mail($admin_email, $subject, $message, $headers);
    
            // Crie um objeto de resposta
            $response = array(
                'status' => 'success',
                'message' => 'Orçamento enviado com sucesso!',
            );
    
            // Envie a resposta como JSON de volta para o cliente
            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        } else {
            $response = array(
                'status' => 'error',
                'message' => 'Erro ao processar o orçamento.',
            );
    
            // Envie a resposta de erro como JSON de volta para o cliente
            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        }
    }


    /**
     * Customer aprovation budget action
     * 
     * @since 1.0.0
     * @return void
     */
    public function customer_aprovation_action_callback() {
        if ( isset( $_POST['customer_approval'] ) ) {
            $customer_data = $_POST;
            $approval_status = $customer_data['customer_approval'];
            $get_budget_id = $customer_data['budget_id'];
            $user_budgets = get_option('staker_dynamic_price_rules_user_budgets', array());
            $user_budgets = maybe_unserialize( $user_budgets );
            $admin_email = get_option('admin_email');

            // update customer aprovation info
            $update_budget = array(
                'customer_aprovation' => $approval_status,
            );

            foreach ( $user_budgets as $budget_id => $budget ) {
                if ( isset( $user_budgets[$budget_id] ) ) {
                    $user_budgets[$get_budget_id] = array_merge( $user_budgets[$get_budget_id], $update_budget );
                }
            }

            // Update option with merged data
            update_option('staker_dynamic_price_rules_user_budgets', maybe_serialize( $user_budgets ) );

            if ( $approval_status === 'approved' ) {
                $subject = sprintf( __( 'Parabéns! O orçamento %s foi aceito!', 'staker-dynamic-price-rules' ), $get_budget_id );
                $message = __('Verifique os detalhes do orçamento em seu painel administrativo', 'staker-dynamic-price-rules' );
                $headers = array('Content-Type: text/html; charset=UTF-8');
        
                wp_mail( $admin_email, $subject, $message, $headers );
            } elseif ( $approval_status === 'declined' ) {
                $subject = sprintf( __( 'O orçamento %s foi recusado pelo cliente', 'staker-dynamic-price-rules' ), $get_budget_id );
                $message = __('Verifique os detalhes do orçamento em seu painel administrativo', 'staker-dynamic-price-rules' );
                $headers = array('Content-Type: text/html; charset=UTF-8');
        
                wp_mail( $admin_email, $subject, $message, $headers );
            }
    
            // Crie um objeto de resposta
            $response = array(
                'status' => 'success',
                'approval' => $customer_data,
                'message' => 'Orçamento teve sua aprovação alterado com sucesso!',
            );
    
            // Envie a resposta como JSON de volta para o cliente
            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        } else {
            $response = array(
                'status' => 'error',
                'message' => 'Erro ao alterar a aprovação do orçamento.',
            );
    
            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        }
    }


    /**
     * Set budget ID
     * 
     * @since 1.0.0
     * @return string
     */
    public function get_next_budget_id() {
        $last_budget_id = get_option('sdpr_last_budget_id', 10130); // 10130 is initial value for ID
        $next_budget_id = $last_budget_id + 1;
        update_option('sdpr_last_budget_id', $next_budget_id);

        return $next_budget_id;
    }
}

new Staker_Dynamic_Price_Rules_Budget();