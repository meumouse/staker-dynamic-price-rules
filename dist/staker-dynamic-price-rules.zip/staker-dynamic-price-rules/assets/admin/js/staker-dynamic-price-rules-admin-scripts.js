(function ($) {
    "use strict";

	/**
	 * Activate tabs
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		// Reads the index stored in localStorage, if it exists
		let activeTabIndex = localStorage.getItem('activeTabIndex');

		if (activeTabIndex === null) {
			// If it is null, activate the general tab
			$('.staker-dynamic-price-rules-wrapper a.nav-tab[href="#general"]').click();
		} else {
			$('.staker-dynamic-price-rules-wrapper a.nav-tab').eq(activeTabIndex).click();
		}
	});
		
	$(document).on('click', '.staker-dynamic-price-rules-wrapper a.nav-tab', function() {
		// Stores the index of the active tab in localStorage
		let tabIndex = $(this).index();
		localStorage.setItem('activeTabIndex', tabIndex);
		
		let attrHref = $(this).attr('href');
		
		$('.staker-dynamic-price-rules-wrapper a.nav-tab').removeClass('nav-tab-active');
		$('.staker-dynamic-price-rules-form .nav-content').removeClass('active');
		$(this).addClass('nav-tab-active');
		$('.staker-dynamic-price-rules-form').find(attrHref).addClass('active');
		
		return false;
	});

	/**
	 * Hide toast on click button or after 5 seconds
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		$('.hide-toast').click( function() {
			$('.update-notice-sdpr').fadeOut('fast');
		});

		setTimeout( function() {
			$('.update-notice-sdpr').fadeOut('fast');
		}, 3000);
	});


	/**
	 * Save options in AJAX
	 * 
	 * @since 1.2.0
	 */
	jQuery( function($) {
		let settingsForm = $('form[name="staker-dynamic-price-rules"]');
		let originalValues = settingsForm.serialize();
		var notificationDelay;
	
		settingsForm.on('change', function() {
			if (settingsForm.serialize() != originalValues) {
				ajax_save_options(); // send option serialized on change
			}
		});
	
		function ajax_save_options() {
			$.ajax({
			   url: sdpr_admin_params.ajax_url,
			   type: 'POST',
			   data: {
				  action: 'staker_dynamic_price_rules_ajax_save_options',
				  form_data: settingsForm.serialize(),
			   },
			   success: function (response) {
				  try {
					 var responseData = JSON.parse(response); // Parse the JSON response
	  
					 if (responseData.status === 'success') {
						originalValues = settingsForm.serialize();
						$('.update-notice-sdpr').addClass('active');
	  
						if (notificationDelay) {
						   clearTimeout(notificationDelay);
						}
	  
						notificationDelay = setTimeout(function () {
						   $('.update-notice-sdpr').fadeOut('fast', function () {
							  $(this).removeClass('active').css('display', '');
						   });
						}, 3000);
					 }
				  } catch (error) {
					 console.log(error);
				  }
			   },
			});
		 }
	});


	/**
	 * Allow only number bigger or equal 1 in inputs
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		let inputField = $('.allow-numbers-be-1');
		
		inputField.on('input', function() {
			let inputValue = $(this).val();
		
			if (inputValue > 1) {
				$(this).val(inputValue);
			} else {
				$(this).val(1);
			}
		});
	});


	/**
	 * Change container visibility on click
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		/**
		 * Function to change container visibility
		 * @param {string} method - activation element selector
		 * @param {string} container - container selector
		 */
		function toggleContainerVisibility(method, container) {
			let checked = $(method).prop('checked');

			$(container).toggleClass('d-none', !checked);
		}
	
		toggleContainerVisibility('#enable_user_levels', '.set-user-levels');
		$('#enable_user_levels').click( function() {
			toggleContainerVisibility('#enable_user_levels', '.set-user-levels');
		});

		toggleContainerVisibility('#enable_budge_feature', '.budget-container');
		$('#enable_budge_feature').click( function() {
			toggleContainerVisibility('#enable_budge_feature', '.budget-container');
		});

		toggleContainerVisibility('#enable_bargain_prices', '.negotiate-container');
		$('#enable_bargain_prices').click( function() {
			toggleContainerVisibility('#enable_bargain_prices', '.negotiate-container');
		});
	});


	/**
	 * Create loop dynamic on change value of #set_limit_levels
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		// Event listener for #set_limit_levels field change
		$('#set_limit_levels').on('change', function () {
			let limitLevels = parseInt($(this).val()); // Get the new value
			let existingValues = {};

			// Store the existing values for both 'amount' and 'name' fields
			$('input[name^="set_user_level["]').each(function () {
				let fieldName = $(this).attr('name');
				existingValues[fieldName] = $(this).val();
			});

			// Generate the HTML loop based on the new limit_levels value
			let newHTML = '<fieldset id="set-user-levels-fieldset">';

			for (let i = 1; i <= limitLevels; i++) {
				let nameFieldName = `set_user_level[${i}][name]`;
				let currentNameValue = existingValues[nameFieldName] || `Level ${i}`;

				newHTML += `<div class="input-group mb-3" data-user-levels="${i}">
						<input type="text" class="get-user-level-number-array input-control-wd-5 border-right-0" disabled value="${i}" />
						<input type="text" class="form-control input-control-wd-10 text-center" name="${nameFieldName}" placeholder="Level ${i}" value="${currentNameValue}" />
					</div>`;
			}

			newHTML += '</fieldset>';

			// Replace the existing HTML with the updated loop
			$('#set-user-levels-fieldset').replaceWith(newHTML);
		});
	});


	/**
	 * Add or exclude discount for payment condition on loop
	 * 
	 * @since 1.0.0
	 */
	jQuery( function ($) {
		// event for open popup
		$(".sdpr-display-popup").click(function(e) {
			e.preventDefault();
			var i = $(this).data('popup');
			openPopup(i);
		});
	
		// event for close popup
		$(".sdpr-close-popup").click(function(e) {
			e.preventDefault();
			var i = $(this).closest(".sdpr-popup-container").data('popup-container');
			closePopup(i);
		});
	
		// opten popup
		function openPopup(i) {
			var popupContainer = $(".container-item-" + i);
			popupContainer.addClass('show');
		}
	
		// close popup
		function closePopup(i) {
			var popupContainer = $(".container-item-" + i);
			popupContainer.removeClass('show');
		}
	
		// event for add new discount per payment method
		$(document).on("click", ".add-new-payment-conditions", function(e) {
			e.preventDefault();
			var $container = $(this).closest(".levels-conditions-item");
			var i = $container.data('condition-item');
			var $itemsContainer = $container.find(".discount-container-item-" + i);
			var newIndex = $itemsContainer.find(".levels-condition-item").length + 1;
			var gatewayOptions = "";
	
			// create loop with WooCommerce gateway options
			$.each(sdpr_admin_params.gateway_option, function(gatewayId, gatewayTitle) {
				gatewayOptions += '<option value="' + gatewayId + '">' + gatewayTitle + '</option>';
			});
	
			var newItem = `<div class="levels-condition-item d-flex" data-levels-condition-item="${newIndex}">
				<div class="input-group mb-3">
					<input type="text" class="form-control input-control-wd-5 border-right-0 allow-numbers-be-1 text-center" name="set_user_level_discounts[${i}][${newIndex}][amount]" placeholder="3" value="0" />
					<select class="form-select select-middle-group" name="set_user_level_discounts[${i}][${newIndex}][type]">
						<option value="percentage" selected="selected">${sdpr_admin_params.discount_condition_type_percentage}</option>
						<option value="fixed">${sdpr_admin_params.discount_condition_type_fixed}</option>
					</select>
					<select class="form-select set-payment-gateway-condition" name="set_user_level_discounts[${i}][${newIndex}][gateway]">
						<option value="0">${sdpr_admin_params.discount_condition_gateway_empty}</option>
						${gatewayOptions}
					</select>
				</div>
				<button class="exclude-payment-condition-item btn btn-outline-danger btn-icon ms-3">
					<svg class="staker-dynamic-price-rules-danger-icon" width="20" height="20" viewBox="0 0 24 24"><path d="M15 2H9c-1.103 0-2 .897-2 2v2H3v2h2v12c0 1.103.897 2 2 2h10c1.103 0 2-.897 2-2V8h2V6h-4V4c0-1.103-.897-2-2-2zM9 4h6v2H9V4zm8 16H7V8h10v12z"></path></svg>
				</button>
			</div>`;
	
			$itemsContainer.append(newItem);
			updateHiddenInputs(i);
		});
	
		// exclude event discount condition item
		$(document).on("click", ".exclude-payment-condition-item", function(e) {
			e.preventDefault();
			var i = $(this).closest('.levels-conditions-item').data('condition-item');
			var parentContainer = $(this).closest(".levels-condition-item");

			parentContainer.remove();
			updateHiddenInputs(i);
		});
	
		// update input hidden value
		function updateHiddenInputs(i) {
			var newIndex = $(".discount-container-item-" + i + " .levels-condition-item").length;

			$(".get-value-for-payment-condition[data-level=" + i + "]").val(newIndex).trigger('change');
		}
	});


	/**
	 * Enabled payment method per level
	 * 
	 * @since 1.0.0
	 */
	jQuery( function ($) {
		// open popup
		$('.sdpr-display-popup-payments').on('click', function (event) {
			event.preventDefault();
	
			const popupContainer = $(this).closest('.payment-conditions-item').find('.sdpr-popup-container-payments');
			popupContainer.addClass('show');
		});
	
		// close popup
		$('.sdpr-close-popup-payments').on('click', function (event) {
			event.preventDefault();
	
			const popupContainer = $(this).closest('.sdpr-popup-container-payments');
			popupContainer.removeClass('show');
		});
	});


	/**
	 * Open WordPress midia library popup on click
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		var file_frame;
	
		$('#get_logo_for_budgets').on('click', function(e) {
			e.preventDefault();
	
			// If the media frame already exists, reopen it
			if (file_frame) {
				file_frame.open();
				return;
			}
	
			// create midia frame
			file_frame = wp.media.frames.file_frame = wp.media({
				title: 'Escolher logo para orçamentos',
				button: {
					text: 'Usar esta imagem'
				},
				multiple: false
			});
	
			// When an image is selected, execute the callback function
			file_frame.on('select', function() {
				var attachment = file_frame.state().get('selection').first().toJSON();
				var imageUrl = attachment.url;
			
				// Update the input value with the URL of the selected image
				$('input[name="display_logo_budgets"]').val(imageUrl).trigger('change'); // Force change
			});

			file_frame.open();
		});
	});


	/**
	 * Advanced conditions
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		// open popup
		$('.sdpr-display-popup-advanced-conditions').on('click', function (event) {
			event.preventDefault();
	
			$('.sdpr-popup-container-advanced-conditions').addClass('show');
		});
	
		// close popup
		$('.sdpr-close-popup-advanced-conditions').on('click', function (event) {
			event.preventDefault();
	
			$('.sdpr-popup-container-advanced-conditions').removeClass('show');
		});

		/**
		 * Initialize Bootstrap datepicker
		 */
		function initDatepicker() {
			$('.dateselect').datepicker({
				format: "dd/mm/yyyy",
				todayHighlight: true,
				language: "pt-BR",
			});
		}
		
		// Chame a função para inicializar o datepicker nos elementos existentes
		initDatepicker();
		
		// Manipulador de eventos delegados para elementos futuros
		$(document).on('focus', '.dateselect', function () {
			if (!$(this).data('datepicker')) {
				$(this).datepicker({
					format: "dd/mm/yyyy",
					todayHighlight: true,
					language: "pt-BR",
				});
			}
		});


		/**
		 * Display container of specific products, categories or attributes if corresponding option is selected
		 */
		function saveProductFilterContainerState(loopNumber, selectedOption) {
			localStorage.setItem('container_product_filter_state_' + loopNumber, selectedOption);
		}
		
		// Função para aplicar o estado dos contêineres com base no valor selecionado
		function applyProductFilterContainerState(loopNumber) {
			var selectedOption = localStorage.getItem('container_product_filter_state_' + loopNumber);
			var specificProducts = $('.specific-products[data-loop-number="' + loopNumber + '"]');
			var specificCategories = $('.specific-categories[data-loop-number="' + loopNumber + '"]');
			var specificAttributes = $('.specific-attributes[data-loop-number="' + loopNumber + '"]');
		
			specificProducts.toggleClass('d-none', selectedOption !== 'select_specific_products');
			specificCategories.toggleClass('d-none', selectedOption !== 'select_specific_categories');
			specificAttributes.toggleClass('d-none', selectedOption !== 'select_specific_attributes');
		}
		
		// Evento de mudança no select
		$(document).on('change', 'select.product-filter[data-loop-number]', function () {
			var loopNumber = $(this).data('loop-number');
			var selectedOption = $(this).val();
		
			// Armazena o estado atual no localStorage
			saveProductFilterContainerState(loopNumber, selectedOption);
		
			// Aplica o estado dos contêineres
			applyProductFilterContainerState(loopNumber);
		});
		
		// Aplicar estados dos contêineres ao carregar a página
		$('select.product-filter[data-loop-number]').each(function () {
			var loopNumber = $(this).data('loop-number');
			applyProductFilterContainerState(loopNumber);
		});


		/**
		 * Display container of specific users or roles if corresponding option is selected
		 */
		function saveUserRoleContainerState(loopNumber, selectedOption) {
			localStorage.setItem('container_user_role_state_' + loopNumber, selectedOption);
		}
		
		// Função para aplicar o estado dos contêineres com base no valor selecionado
		function applyUserRoleContainerState(loopNumber) {
			var selectedOption = localStorage.getItem('container_user_role_state_' + loopNumber);
			var specificUsersContainer = $('.specific-users-container[data-loop-number="' + loopNumber + '"]');
			var specificRolesContainer = $('.specific-roles-container[data-loop-number="' + loopNumber + '"]');
		
			specificUsersContainer.toggleClass('d-none', selectedOption !== 'specific_user');
			specificRolesContainer.toggleClass('d-none', selectedOption !== 'specific_role');
		}
		
		// Evento de mudança no select
		$(document).on('change', 'select.user-role-filter[data-loop-number]', function () {
			var loopNumber = $(this).data('loop-number');
			var selectedOption = $(this).val();
		
			// Armazena o estado atual no localStorage
			saveUserRoleContainerState(loopNumber, selectedOption);
		
			// Aplica o estado dos contêineres
			applyUserRoleContainerState(loopNumber);
		});
		
		// Aplicar estados dos contêineres ao carregar a página
		$('select.user-role-filter[data-loop-number]').each(function () {
			var loopNumber = $(this).data('loop-number');
			applyUserRoleContainerState(loopNumber);
		});


		/**
		 * Show rule type container if corresponding option is selected
		 */
		function saveRuleTypeContainerState(loopNumber, selectedOption) {
			localStorage.setItem('container_rule_type_state_' + loopNumber, selectedOption);
		}
		
		// Função para aplicar o estado dos contêineres com base no valor selecionado
		function applyRuleTypeContainerState(loopNumber) {
			var selectedOption = localStorage.getItem('container_rule_type_state_' + loopNumber);
			var discountContainer = $('.manage-discounts[data-loop-number="' + loopNumber + '"]');
			var shippingContainer = $('.manage-shipping[data-loop-number="' + loopNumber + '"]');
		
			discountContainer.toggleClass('d-none', selectedOption !== 'discount');
			shippingContainer.toggleClass('d-none', selectedOption !== 'shipping');
		}
		
		// Evento de mudança no select
		$(document).on('change', 'select.rule-type[data-loop-number]', function () {
			var loopNumber = $(this).data('loop-number');
			var selectedOption = $(this).val();
		
			// Armazena o estado atual no localStorage
			saveRuleTypeContainerState(loopNumber, selectedOption);
		
			// Aplica o estado dos contêineres
			applyRuleTypeContainerState(loopNumber);
		});
		
		// Aplicar estados dos contêineres ao carregar a página
		$('select.rule-type[data-loop-number]').each(function () {
			var loopNumber = $(this).data('loop-number');
			applyRuleTypeContainerState(loopNumber);
		});


		/**
		 * Display minimum quantity input if corresponding option is selected
		 */
		function saveDiscountMethodContainerState(loopNumber, selectedOption) {
			localStorage.setItem('container_discount_method_state_' + loopNumber, selectedOption);
		}
		
		// Função para aplicar o estado dos contêineres com base no valor selecionado
		function applyDiscountMethodContainerState(loopNumber) {
			var selectedOption = localStorage.getItem('container_discount_method_state_' + loopNumber);
			var minQtdInput = $('input.min-qtd-aplly-discount[data-loop-number="' + loopNumber + '"]');
		
			minQtdInput.toggleClass('d-none', selectedOption !== 'quantity');
		}
		
		// Evento de mudança no select
		$(document).on('change', 'select.discount-method[data-loop-number]', function () {
			var loopNumber = $(this).data('loop-number');
			var selectedOption = $(this).val();
		
			// Armazena o estado atual no localStorage
			saveDiscountMethodContainerState(loopNumber, selectedOption);
		
			// Aplica o estado dos contêineres
			applyDiscountMethodContainerState(loopNumber);
		});
		
		// Aplicar estados dos contêineres ao carregar a página
		$('select.discount-method[data-loop-number]').each(function () {
			var loopNumber = $(this).data('loop-number');
			applyDiscountMethodContainerState(loopNumber);
		});


		/**
		 * Get WooCommerce products in AJAX
		 */
		$(document).on('keyup', '.product-search', function() {
			var loopNumber = $(this).data('loop-number');
			var searchQuery = $(this).val();
		
			if (searchQuery.length >= 3) {
				$('.ajax-search-with-loader[data-loop-number="' + loopNumber + '"] .spinner-border').removeClass('d-none');
		
				$.ajax({
					url: sdpr_admin_params.ajax_url,
					type: 'POST',
					data: {
						action: 'get_woo_products_ajax',
						search_query: searchQuery
					},
					success: function(response) {
						$('.ajax-search-with-loader[data-loop-number="' + loopNumber + '"] .spinner-border').addClass('d-none');
						$('.specific-product-results[data-loop-number="' + loopNumber + '"]').removeClass('d-none');
						$('#product-results-' + loopNumber).html(response);
		
						// Keep selected products after searching
						var selectedIds = $('input[data-save-specific-products="' + loopNumber + '"]').val().split(',').map(Number);
		
						selectedIds.forEach(function(productId) {
							if (productId !== 0) {
								$('#product-results-' + loopNumber + ' li[data-product-id="' + productId + '"]').addClass('selected');
							}
						});
					}
				});
			} else {
				$('#product-results-' + loopNumber).html('');
			}
		});
		
		// Manipulador de eventos delegados para clicar em itens
		$(document).on('click', '.specific-product-results ul.list-group li', function() {
			var loopNumber = $(this).closest('.specific-product-results').data('loop-number');
			var productId = $(this).data('product-id');
		
			// Toggle the "selected" class when clicking on an item
			$(this).toggleClass('selected');
		
			// Atualize o input oculto com IDs selecionados
			var selectedIds = $('input[data-save-specific-products="' + loopNumber + '"]').val().split(',').map(Number);
		
			if ($(this).hasClass('selected')) {
				if (productId !== 0) {
					selectedIds.push(productId);
				}
			} else {
				// Remova o ID do produto da lista selecionada
				var index = selectedIds.indexOf(productId);
		
				if (index !== -1) {
					selectedIds.splice(index, 1);
				}
			}
		
			var selectedIdsString = selectedIds.join(', ');
		
			$('input[data-save-specific-products="' + loopNumber + '"]').val(selectedIdsString).trigger('change');
		});


		/**
		 * Get WooCommerce product categories in AJAX
		 */
		$(document).on('keyup', '.category-search', function() {
			var loopNumber = $(this).data('cat-loop-number');
			var searchQuery = $(this).val();
		
			if (searchQuery.length >= 3) {
				$('.ajax-search-with-loader[data-cat-loop-number="' + loopNumber + '"] .spinner-border').removeClass('d-none');
		
				$.ajax({
					url: sdpr_admin_params.ajax_url,
					type: 'POST',
					data: {
						action: 'get_woo_categories_ajax',
						search_query: searchQuery
					},
					success: function(response) {
						$('.ajax-search-with-loader[data-cat-loop-number="' + loopNumber + '"] .spinner-border').addClass('d-none');
						$('.specific-category-results[data-cat-loop-number="' + loopNumber + '"]').removeClass('d-none');
						$('#category-results-' + loopNumber).html(response);
		
						// Mantenha as categorias selecionadas após a pesquisa
						var selectedCategories = $('input[data-save-specific-categories="' + loopNumber + '"]').val().split(',').map(Number);
		
						selectedCategories.forEach(function(categoryId) {
							if (categoryId !== 0) { // Evite adicionar o número zero
								$('#category-results-' + loopNumber + ' li[data-category-id="' + categoryId + '"]').addClass('selected');
							}
						});
					}
				});
			} else {
				$('#category-results-' + loopNumber).html('');
			}
		});
		
		// Manipulador de eventos delegados para clicar em itens de categoria
		$(document).on('click', '.specific-category-results ul.list-group li', function() {
			var loopNumber = $(this).closest('.specific-category-results').data('cat-loop-number');
			var categoryId = $(this).data('category-id');
		
			// Toggle the "selected" class when clicking on an item
			$(this).toggleClass('selected');
		
			// Atualize o input oculto com IDs de categorias selecionadas
			var selectedCategories = $('input[data-save-specific-categories="' + loopNumber + '"]').val().split(',').map(Number);
		
			if ($(this).hasClass('selected')) {
				if (categoryId !== 0) {
					selectedCategories.push(categoryId);
				}
			} else {
				// Remova o ID da categoria da lista selecionada
				var index = selectedCategories.indexOf(categoryId);
		
				if (index !== -1) {
					selectedCategories.splice(index, 1);
				}
			}
			var selectedCategoriesString = selectedCategories.join(', ');
		
			$('input[data-save-specific-categories="' + loopNumber + '"]').val(selectedCategoriesString).trigger('change');
		});


		/**
		 * Get product attributes in AJAX
		 */
		$(document).on('keyup', '.attribute-search', function() {
			var loopNumber = $(this).data('atr-loop-number');
			var searchQuery = $(this).val();
		
			if (searchQuery.length >= 3) {
				$('.ajax-search-with-loader[data-atr-loop-number="' + loopNumber + '"] .spinner-border').removeClass('d-none');
		
				$.ajax({
					url: sdpr_admin_params.ajax_url,
					type: 'POST',
					data: {
						action: 'get_woo_attributes_ajax',
						search_query: searchQuery
					},
					success: function(response) {
						$('.ajax-search-with-loader[data-atr-loop-number="' + loopNumber + '"] .spinner-border').addClass('d-none');
						$('.specific-attribute-results[data-atr-loop-number="' + loopNumber + '"]').removeClass('d-none');
						$('#attribute-results-' + loopNumber).html(response);
		
						// Mantenha os atributos selecionados após a pesquisa
						var selectedAttributes = $('input[data-save-specific-attributes="' + loopNumber + '"]').val().split(',').map(Number);
		
						selectedAttributes.forEach(function(attributeId) {
							if (attributeId !== 0) {
								$('#attribute-results-' + loopNumber + ' li[data-attribute-id="' + attributeId + '"]').addClass('selected');
							}
						});
					}
				});
			} else {
				$('#attribute-results-' + loopNumber).html('');
			}
		});
		
		// Manipulador de eventos delegados para clicar em itens de atributo
		$(document).on('click', '.specific-attribute-results ul.list-group li', function() {
			var loopNumber = $(this).closest('.specific-attribute-results').data('atr-loop-number');
			var attributeId = $(this).data('attribute-id');
		
			// Toggle the "selected" class when clicking on an item
			$(this).toggleClass('selected');
		
			// Atualize o input oculto com IDs de atributos selecionados
			var selectedAttributes = $('input[data-save-specific-attributes="' + loopNumber + '"]').val().split(',').map(Number);
		
			if ($(this).hasClass('selected')) {
				if (attributeId !== 0) {
					selectedAttributes.push(attributeId);
				}
			} else {
				// Remova o ID do atributo da lista selecionada
				var index = selectedAttributes.indexOf(attributeId);
		
				if (index !== -1) {
					selectedAttributes.splice(index, 1);
				}
			}
		
			var selectedAttributesString = selectedAttributes.join(', ');
		
			$('input[data-save-specific-attributes="' + loopNumber + '"]').val(selectedAttributesString).trigger('change');
		});


		/**
		 * Get WP users in AJAX
		 */
		$(document).on('keyup', '.user-search', function() {
			var loopNumber = $(this).data('user-search');
			var searchQuery = $(this).val();
		
			if (searchQuery.length >= 3) {
				$('.ajax-search-with-loader[data-user-search="' + loopNumber + '"] .spinner-border').removeClass('d-none');
		
				$.ajax({
					url: sdpr_admin_params.ajax_url,
					type: 'POST',
					data: {
						action: 'search_users',
						search_query: searchQuery
					},
					success: function(response) {
						$('.ajax-search-with-loader[data-user-search="' + loopNumber + '"] .spinner-border').addClass('d-none');
						$('.specific-user-results[data-user-results="' + loopNumber + '"]').removeClass('d-none');
						$('#user-results-' + loopNumber).html(response);
		
						// Mantenha os usuários selecionados após a pesquisa
						var selectedUsers = $('input[data-save-specific-users="' + loopNumber + '"]').val().split(',').map(Number);
		
						selectedUsers.forEach(function(userId) {
							if (userId !== 0) {
								$('#user-results-' + loopNumber + ' li[data-user-id="' + userId + '"]').addClass('selected');
							}
						});
					}
				});
			} else {
				$('#user-results-' + loopNumber).html('');
			}
		});
		
		// Manipulador de eventos delegados para clicar em itens da lista de usuários
		$(document).on('click', '.specific-user-results ul.list-group li', function() {
			var loopNumber = $(this).closest('.specific-user-results').data('user-results');
			var userId = $(this).data('user-id');
		
			// Alternar a classe "selected" ao clicar em um usuário
			$(this).toggleClass('selected');
		
			// Atualizar o input hidden com os IDs de usuário selecionados
			var selectedUsers = $('input[data-save-specific-users="' + loopNumber + '"]').val().split(',').map(Number);
		
			if ($(this).hasClass('selected')) {
				if (userId !== 0) {
					selectedUsers.push(userId);
				}
			} else {
				// Remover o ID do usuário da lista selecionada
				var index = selectedUsers.indexOf(userId);
		
				if (index !== -1) {
					selectedUsers.splice(index, 1);
				}
			}
		
			var selectedUsersString = selectedUsers.join(', ');
		
			$('input[data-save-specific-users="' + loopNumber + '"]').val(selectedUsersString).trigger('change');
		});


		/**
		 * Add or exclude items of for loop
		 */
		$(document).on('click', '.add-new-advanced-condition', function(e) {
			e.preventDefault();
			var a = $('.advanced-condition-item').length;
			var container = $('.advanced-condition-item[data-loop-number="' + a + '"]');
			var newIndex = a + 1;
			var shippingOptions = '';
			var roleOptions = '';
			var loopCounter = $("#loop-counter-advanced-conditions");
			var currentValue = parseInt(loopCounter.val());
	
			// create loop with WooCommerce gateway options
			$.each(sdpr_admin_params.shipping_option, function(shippingId, shippingTitle) {
				shippingOptions += '<option value="' + shippingId + '">' + shippingTitle + '</option>';
			});

			// create loop with user roles
			$.each(sdpr_admin_params.role_option, function(roleId, roleTitle) {
				roleOptions += '<option value="' + roleId + '">' + roleTitle + '</option>';
			});
	
			var newItem = `<div class="advanced-condition-item" data-advanced-condition-item="${newIndex}" data-loop-number="${newIndex}">

			<div class="first-line-settings">
			  <div class="rule-type-item d-grid me-3">
				<label class="form-label">${sdpr_admin_params.rule_type_label}</label>

				<select class="form-select rule-type" data-rule-type-item="${newIndex}" name="advanced_condition[${newIndex}][rule_type]" data-loop-number="${newIndex}">
				  <option value="0">${sdpr_admin_params.rule_type_empty}</option>
				  <option value="discount">${sdpr_admin_params.rule_type_discount}</option>
				  <option value="shipping">${sdpr_admin_params.rule_type_shipping}</option>
				</select>
			  </div>

			  <div class="user-role-item d-grid me-3">
				<label class="form-label">${sdpr_admin_params.user_role_label}</label>

				<select class="form-select user-role-filter" name="advanced_condition[${newIndex}][user_role]" data-loop-number="${newIndex}">
				  <option value="all_users">${sdpr_admin_params.user_role_all_users}</option>
				  <option value="all_roles">${sdpr_admin_params.user_role_all_roles}</option>
				  <option value="specific_user">${sdpr_admin_params.user_role_specific_users}</option>
				  <option value="specific_role">${sdpr_admin_params.user_role_specific_roles}</option>
				</select>
			  </div>

			  <div class="product-filter-item d-grid me-3">
				<label class="form-label">${sdpr_admin_params.product_filter_label}</label>

				<select class="form-select product-filter" name="advanced_condition[${newIndex}][product_filter]" data-loop-number="${newIndex}">
				  <option value="all_products">${sdpr_admin_params.product_filter_all_products}</option>
				  <option value="all_categories">${sdpr_admin_params.product_filter_all_categories}</option>
				  <option value="all_attributes">${sdpr_admin_params.product_filter_all_attributes}</option>
				  <option value="select_specific_products">${sdpr_admin_params.product_filter_specific_products}</option>
				  <option value="select_specific_categories">${sdpr_admin_params.product_filter_specific_categories}</option>
				  <option value="select_specific_attributes">${sdpr_admin_params.product_filter_specific_attributes}</option>
				</select>
			  </div>

			  <button class="exclude-advanced-condition-item btn btn-outline-danger btn-icon" data-exclude-advanced-item="${newIndex}">
				<svg class="staker-dynamic-price-rules-danger-icon" width="20" height="20" viewBox="0 0 24 24"><path d="M15 2H9c-1.103 0-2 .897-2 2v2H3v2h2v12c0 1.103.897 2 2 2h10c1.103 0 2-.897 2-2V8h2V6h-4V4c0-1.103-.897-2-2-2zM9 4h6v2H9V4zm8 16H7V8h10v12z"></path></svg>
			  </button>
			</div>

			<div class="specific-users-container get-specific-value mt-4 mb-5 d-none" data-specific-users-item="${newIndex}" data-loop-number="${newIndex}">
				<label class="form-label">${sdpr_admin_params.user_role_specific_users}</label>
				<div class="d-flex align-items-center ajax-search-with-loader">
					<input type="text" class="form-control user-search" data-user-search="${newIndex}" placeholder="${sdpr_admin_params.search_placeholder}">
					<span class="spinner-border d-none"></span>
				</div>
				<div class="specific-user-results d-none" data-user-results="${newIndex}">
					<ul id="user-results-${newIndex}" class="list-group list-itens-overflow"></ul>
				</div>
				<input type="hidden" name="advanced_condition[${newIndex}][specific_users]" value="" data-save-specific-users="${newIndex}" />
			</div>

			<div class="specific-roles-container get-specific-value mt-4 mb-5 d-none" data-specific-roles="${newIndex}" data-loop-number="${newIndex}">
			  <label class="form-label">${sdpr_admin_params.user_role_specific_roles}</label>
			  <select class="form-select specific-roles" name="advanced_condition[${newIndex}][specific_roles]" data-loop-count="${newIndex}">
				  ${roleOptions}
			  </select>
			</div>
			
			<div class="specific-products get-specific-value mt-4 mb-5 d-none" data-loop-number="${newIndex}">
				<label class="form-label">${sdpr_admin_params.product_filter_specific_products}</label>
				<div class="d-flex align-items-center ajax-search-with-loader" data-loop-number="${newIndex}">
					<input type="text" class="form-control product-search" data-loop-number="${newIndex}" placeholder="${sdpr_admin_params.search_placeholder}">
					<span class="spinner-border d-none"></span>
				</div>
				<div class="specific-product-results d-none" data-loop-number="${newIndex}">
					<ul id="product-results-${newIndex}" class="list-group list-itens-overflow"></ul>
				</div>
				<input type="hidden" name="advanced_condition[${newIndex}][specific_products]" value="" data-save-specific-products="${newIndex}" />
			</div>

			<div class="specific-categories get-specific-value mt-4 mb-5 d-none" data-loop-number="${newIndex}">
			  <label class="form-label">${sdpr_admin_params.product_filter_specific_categories}</label>
			  <div class="d-flex align-items-center ajax-search-with-loader" data-cat-loop-number="${newIndex}">
				<input type="text" class="form-control category-search" data-cat-loop-number="${newIndex}" placeholder="${sdpr_admin_params.search_placeholder}">
				<span class="spinner-border d-none"></span>
			  </div>
			  <div class="specific-category-results d-none" data-cat-loop-number="${newIndex}">
				  <ul id="category-results-${newIndex}" class="list-group list-itens-overflow"></ul>
			  </div>
			  <input type="hidden" name="advanced_condition[${newIndex}][specific_categories]" value="" data-save-specific-categories="${newIndex}"/>
			</div>

			<div class="specific-attributes get-specific-value mt-4 mb-5 d-none" data-loop-number="${newIndex}">
			  <label class="form-label">${sdpr_admin_params.product_filter_specific_attributes}</label>
			  <div class="d-flex align-items-center ajax-search-with-loader" data-atr-loop-number="${newIndex}">
				  <input type="text" class="form-control attribute-search" data-atr-loop-number="${newIndex}" placeholder="${sdpr_admin_params.search_placeholder}">
				  <span class="spinner-border d-none"></span>
			  </div>
			  <div class="specific-attribute-results d-none" data-atr-loop-number="${newIndex}">
				  <ul id="attribute-results-${newIndex}" class="list-group list-itens-overflow"></ul>
			  </div>
			  <input type="hidden" name="advanced_condition[${newIndex}][specific_attributes]" value="" data-save-specific-attributes="${newIndex}"/>
			</div>

			<div class="second-line-settings manage-discounts mt-4 mb-5 d-none" data-apply-discount-item="${newIndex}" data-loop-number="${newIndex}">
			  <label class="form-label">${sdpr_admin_params.discount_label}</label>
			  <div class="input-group mb-3">
				<select class="form-select discount-method" name="advanced_condition[${newIndex}][apply_discount_method]" data-loop-number="${newIndex}">
				  <option value="cart">${sdpr_admin_params.discount_cart}</option>
				  <option value="quantity">${sdpr_admin_params.discount_quantity}</option>
				</select>

				<input type="number" class="form-control border-right-0 min-qtd-aplly-discount d-none" name="advanced_condition[${newIndex}][min_qtd]" data-loop-number="${newIndex}" value="" placeholder="${sdpr_admin_params.min_qtd_placeholder}"/>
				
				<select class="form-select select-middle-group" name="advanced_condition[${newIndex}][discount_method]">
				  <option value="percentage">${sdpr_admin_params.discount_method_percentage}</option>
				  <option value="fixed">${sdpr_admin_params.discount_method_fixed}</option>
				</select>

				<input type="number" class="form-control" name="advanced_condition[${newIndex}][discount_value]" value="" placeholder="${sdpr_admin_params.discount_value_placeholder}"/>
			  </div>
			</div>

			<div class="second-line-settings manage-shipping mt-4 mb-5 d-none" data-shipping-method-item="${newIndex}" data-loop-number="${newIndex}">
			  <label class="form-label">${sdpr_admin_params.shipping_label}</label>
			  <div class="input-group mb-3">
				<select class="form-select set-payment-gateway-condition" name="advanced_condition[${newIndex}][shipping_method]">
					<option value="0">${sdpr_admin_params.adv_conditions_shipping_empty}</option>
					${shippingOptions}
				</select>
				<select class="form-select set-payment-gateway-condition" name="advanced_condition[${newIndex}][shipping_operator]">
					<option value="0">${sdpr_admin_params.rule_type_operator_empty}</option>
					<option value="remove">${sdpr_admin_params.rule_type_operator_remove}</option>
				</select>
			  </div>
			</div>

			<div class="third-line-settings manage-conditions text-left mt-4 mb-5">
			  <label class="form-label">${sdpr_admin_params.conditions_label}</label>
			  <div class="input-group mb-3">

				<select class="form-select" name="advanced_condition[${newIndex}][apply_condition]">
				  <option value="0">${sdpr_admin_params.empty_condition}</option>
				  <option value="cart_qtd_total">${sdpr_admin_params.conditions_cart_qtd_total}</option>
				  <option value="cart_value_total">${sdpr_admin_params.conditions_cart_value_total}</option>
				  <option value="user_level">${sdpr_admin_params.conditions_user_level}</option>
				</select>

				<select class="form-select select-middle-group" name="advanced_condition[${newIndex}][operator_condition]">
				  <option value="0">${sdpr_admin_params.operator_condition_empty}</option>
				  <option value="less_than">${sdpr_admin_params.operator_condition_less_than}</option>
				  <option value="less_than_or_equal">${sdpr_admin_params.operator_condition_less_than_or_equal}</option>
				  <option value="greater_than">${sdpr_admin_params.operator_condition_greater_than}</option>
				  <option value="greater_than_or_equal">${sdpr_admin_params.operator_condition_greater_than_or_equal}</option>
				  <option value="equal">${sdpr_admin_params.operator_condition_equal}</option>
				  <option value="different">${sdpr_admin_params.operator_condition_different}</option>
				</select>

				<input type="text" class="form-control" name="advanced_condition[${newIndex}][condition_value]" value="" placeholder="${sdpr_admin_params.condition_value_plceholder}"/>
			  </div>
			</div>

			<div class="fourth-line-settings manage-limit mt-4 mb-3">
			  <label class="form-label mb-2">${sdpr_admin_params.manage_limit_label}</label>
			  <div class="d-flex mt-3">
				<div class="w-33 me-3">
				  <label class="form-label">${sdpr_admin_params.manage_limit_use}</label>
				  <input type="number" class="form-control" name="advanced_condition[${newIndex}][use_limit]" value="" placeholder="${sdpr_admin_params.manage_limit_use_placeholder}"/>
				</div>
				<div class="w-33 me-3">
				  <label class="form-label">${sdpr_admin_params.manage_limit_start_date}</label>
				  <input type="text" class="form-control date-start dateselect" data-loop-number="${newIndex}" name="advanced_condition[${newIndex}][start_date]" value=""/>
				</div>
				<div class="w-33">
				  <label class="form-label">${sdpr_admin_params.manage_limit_end_date}</label>
				  <input type="text" class="form-control date-end dateselect" data-loop-number="${newIndex}" name="advanced_condition[${newIndex}][end_date]" value=""/>
				</div>
			  </div>
			</div>
		  </div>
		</div>`;
	
			// if "advanced-conditions-container" is empty
			if ( a === 0 ) {
				$('.advanced-conditions-container').append(newItem);
			} else {
				container.after(newItem);
			}
			
			loopCounter.val(currentValue + 1).trigger('change');
		});
	
		// exclude event discount condition item
		$(document).on('click', '.exclude-advanced-condition-item', function(e) {
			e.preventDefault();
			var parentContainer = $(this).closest('.advanced-condition-item');

			parentContainer.remove();
			var loopCounter = $("#loop-counter-advanced-conditions");
			var currentValue = parseInt(loopCounter.val());
			loopCounter.val(currentValue - 1).trigger('change');
		});
	});


	/**
	 * Actions to accept or decline user offers via AJAX
	 * 
	 * @since 1.0.0
	 * @return void
	 */
	jQuery( function($) {
		const triggerPopup = $('.sdpr-manage-negotiates-trigger');
		const popupContainer = $('.sdpr-manage-negotiates-container');
		const closePopup = $('.sdpr-close-manage-negotiates');
	
		triggerPopup.on('click', function(e) {
			e.preventDefault();
			popupContainer.addClass('show');
		});
	
		popupContainer.on('click', function(event) {
			if (event.target === this) {
				$(this).removeClass('show');
			}
		});
	
		closePopup.on('click', function(e) {
			e.preventDefault();
			popupContainer.removeClass('show');
		});

		$('.accept-offer').on('click', function(e) {
			e.preventDefault();
			var offerData = $(this).data('offer');
			var ofertaId = offerData.user_id;
			var product_id = offerData.product_id;
			var negotiated_price = offerData.negotiated_price;
			
			// Adicionar classe "ui-block" ao <tr>
			var $offerRow = $(this).closest('tr');
			$offerRow.addClass('ui-block');
		
			$.ajax({
				type: 'POST',
				url: sdpr_admin_params.ajax_url,
				data: {
					action: 'update_offer_status',
					offer_id: ofertaId,
					status: 'accepted',
					product_id: product_id,
					negotiated_price: negotiated_price
				},
				success: function(response) {
					console.log('Oferta aceita com sucesso!');
					setTimeout(function() {
						$offerRow.remove();
					}, 300);
				},
				error: function() {
					console.error('Erro ao aceitar a oferta.');
				}
			});
		});
		
		$('.decline-offer').on('click', function(e) {
			e.preventDefault();
			var offerData = $(this).data('offer');
			var ofertaId = offerData.user_id;
			var product_id = offerData.product_id;
			var negotiated_price = offerData.negotiated_price;
			var $offerRow = $(this).closest('tr');

			$offerRow.addClass('ui-block');
		
			$.ajax({
				type: 'POST',
				url: sdpr_admin_params.ajax_url,
				data: {
					action: 'update_offer_status',
					offer_id: ofertaId,
					status: 'declined',
					product_id: product_id,
					negotiated_price: negotiated_price
				},
				success: function(response) {
					console.log('Oferta recusada com sucesso!');
					setTimeout(function() {
						$offerRow.remove();
					}, 300);
				},
				error: function() {
					console.error('Erro ao recusar a oferta.');
				}
			});
		});
	});


	/**
	 * Manage budgets popup
	 * 
	 * @since 1.0.0
	 */
	jQuery( function ($) {
		const triggerPopup = $('.sdpr-manage-budgets-trigger');
		const popupContainer = $('.sdpr-manage-budgets-container');
		const closePopup = $('.sdpr-close-manage-budgets');
	
		triggerPopup.on('click', function(e) {
			e.preventDefault();
			popupContainer.addClass('show');
		});
	
		closePopup.on('click', function(e) {
			e.preventDefault();
			popupContainer.removeClass('show');
		});
	});


})(jQuery);